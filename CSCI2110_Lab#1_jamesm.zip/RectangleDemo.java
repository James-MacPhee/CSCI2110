/* CSCI 2110 - Lab #1 - Exercise #1

   This program uses simple arithemetic to determine if
   a rectangle or a point is touching another rectangle or contained in another circle. 

   James MacPhee - B00768516 - Sept.11th 2018 */
public class RectangleDemo{
   public static void main(String[] args){
      
      Rectangle rect1 = new Rectangle(10,10,10,10);
      Rectangle rect2 = new Rectangle(10,10,10,10);
      Rectangle rect3 = new Rectangle(12.5,12.5,2.5,2.5);
      Rectangle rect4 = new Rectangle(5,5,5,5);
      Rectangle rect5 = new Rectangle(1,1,1,1);
      Rectangle rect6 = new Rectangle(15,15,10,10);
      Rectangle rect7 = new Rectangle(20,15,10,10);
      //Testing point methods
      System.out.println("Here is true/false results from each rectangle.");
      System.out.println(rect1.contains(12.54,16.78));
      System.out.println(rect1.contains(10,16.78));
      System.out.println(rect1.touches(12.54,16.78));
      System.out.println(rect1.touches(10,16.78));
      //Testing rectangle methods
      System.out.println();
      System.out.println(rect1.contains(rect2));
      System.out.println(rect1.touches(rect2));
      System.out.println(rect1.contains(rect3));
      System.out.println(rect1.touches(rect3));
      System.out.println(rect1.contains(rect4));
      System.out.println(rect1.touches(rect4));
      System.out.println(rect1.contains(rect5));
      System.out.println(rect1.touches(rect5));
      System.out.println(rect1.contains(rect6));
      System.out.println(rect1.touches(rect6));
      System.out.println(rect1.contains(rect7));
      System.out.println(rect1.touches(rect7));
   }
}