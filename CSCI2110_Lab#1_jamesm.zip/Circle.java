/* CSCI 2110 - Lab #1 - Exercise #2

   This program defines a circle object and a few computational methods

   James MacPhee - B00768516 - Sept.11th 2018 */
public class Circle{

   private double xpos,ypos,radius;
   //---Constructors---
   public Circle(){
   }
   public Circle(double xpos,double ypos,double radius){
      this.xpos=xpos; this.ypos=ypos; this.radius=radius;
   }
   //---Get and Set methods---
   public double getXpos(){
      return xpos;
   }
   public void setXpos(double xpos){
      this.xpos=xpos;
   }
   public double getYpos(){
      return ypos;
   }
   public void setYpos(double ypos){
      this.ypos=ypos;
   }
   public double getRadius(){
      return radius;
   }
   public void setRadius(double radius){
      this.radius=radius;
   }
   //---Computational methods---
   public double getArea(){
      return Math.PI*radius*radius;
   }
   public double getCircumference(){
      return 2*Math.PI*radius;
   }
   public boolean contains(double px,double py){
      return Math.sqrt(Math.pow(px-xpos,2)+Math.pow(py-ypos,2))<radius;
   }
   public boolean touches(double px,double py){
      return Math.sqrt(Math.pow(px-xpos,2)+Math.pow(py-ypos,2))==radius;
   }
   public boolean contains(Circle circle){
      return Math.sqrt(Math.pow(circle.getXpos()-xpos,2)+Math.pow(circle.getYpos()-ypos,2))+circle.getRadius()<radius;
   }
   public boolean touches(Circle circle){
      return Math.sqrt(Math.pow(circle.getXpos()-xpos,2)+Math.pow(circle.getYpos()-ypos,2))+circle.getRadius()==radius ||
             Math.sqrt(Math.pow(circle.getXpos()-xpos,2)+Math.pow(circle.getYpos()-ypos,2))-circle.getRadius()==radius;
   }
}