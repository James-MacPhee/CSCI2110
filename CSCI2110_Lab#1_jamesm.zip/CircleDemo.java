/* CSCI 2110 - Lab #1 - Exercise #2

   This program uses simple arithemetic to determine if
   a circle or a point is touching another circle or contained in another circle. 

   James MacPhee - B00768516 - Sept.11th 2018 */
public class CircleDemo{
   public static void main(String[] args){
      
      Circle circle1 = new Circle(10,10,10);
      System.out.printf("Circle Center: (%.2f,%.2f) Radius: %.2f Area: %.2f Circumference: %.2f", circle1.getXpos(), circle1.getYpos(), circle1.getRadius(), circle1.getArea(), circle1.getCircumference());
      System.out.println();
      System.out.println("Here is true/false results from each circle.");
      System.out.println(circle1.contains(12,12));
      System.out.println(circle1.contains(34,26));
      System.out.println(circle1.touches(12,12));
      System.out.println(circle1.touches(10,20));
      System.out.println();
      //Creating test circles
      Circle circle2 = new Circle(12,12,2);
      Circle circle3 = new Circle(13,14,5);
      Circle circle4 = new Circle(25,10,5);
      Circle circle5 = new Circle(19,19,5);
      //Testing containment and touchiness of each circle
      System.out.println(circle1.contains(circle2));
      System.out.println(circle1.touches(circle2));
      System.out.println(circle1.contains(circle3));
      System.out.println(circle1.touches(circle3));
      System.out.println(circle1.contains(circle4));
      System.out.println(circle1.touches(circle4));
      System.out.println(circle1.contains(circle5));
      System.out.println(circle1.touches(circle5));
   }
}