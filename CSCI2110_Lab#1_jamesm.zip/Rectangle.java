/* CSCI 2110 - Lab #1 - Exercise #1

   This program defines a Rectangle object and a few computational methods.

   James MacPhee - B00768516 - Sept.11th 2018 */
public class Rectangle{
   
   private double xpos,ypos,width,height;
   //Constructors
   public Rectangle(){
   }
   public Rectangle(double xpos,double ypos,double width,double height){
      this.xpos=xpos; this.ypos=ypos; this.width=width; this.height=height;
   }
   //---Get and Set Methods---
   public double getXpos(){
      return xpos;
   }
   public void setXpos(double xpos){
      this.xpos=xpos;
   }
   public double getYpos(){
      return ypos;
   }
   public void setYpos(double ypos){
      this.ypos=ypos;
   }
   public double getWidth(){
      return width;
   }
   public void setWidth(double width){
      this.width=width;
   }
   public double getHeight(){
      return height;
   }
   public void setHeight(double height){
      this.height=height;
   }
   //---Contains and touches methods---
   public boolean contains(double px,double py){
      return px>xpos&&py>ypos&&px<xpos+width&&py<ypos+height;
   }
   public boolean touches(double px, double py){
      return (px==xpos&&py>=ypos&&py<=ypos+height)||(py==ypos&&px>=xpos&&px<=xpos+width);
   }
   public boolean contains(Rectangle r){
      return r.getXpos()>xpos&&r.getYpos()>ypos&&r.getXpos()+r.getWidth()<xpos+width&&r.getYpos()+r.getHeight()<ypos+height;
   }
   //Lengthy if statement
   public boolean touches(Rectangle r){
      return (r.getXpos()+r.getWidth()>=xpos&&r.getXpos()<=xpos+width) &&
             (r.getYpos()==ypos||r.getYpos()+r.getHeight()==ypos||r.getYpos()==ypos+height||r.getYpos()+r.getHeight()==ypos+height) ||
             (r.getYpos()+r.getHeight()>=ypos&&r.getYpos()<=ypos+height) &&
             (r.getXpos()==xpos||r.getXpos()+r.getWidth()==xpos||r.getXpos()==xpos+width||r.getXpos()+r.getWidth()==xpos+width);
   }
}
