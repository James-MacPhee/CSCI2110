/* CSCI 2110 - Lab #1 - Exercise3

   This program defines a Rectangle object that is the smallest rectangle that bounds the user-inputted points

   James MacPhee - B00768516 - Sept.11th 2018 */
import java.util.Scanner;
public class Exercise3 {
   public static void main(String[] args) {
      double[][] points = new double[5][2];

      Scanner input = new Scanner(System.in);
      System.out.print("Enter " + points.length + " points: ");
      for (int i = 0; i < points.length; i++) {
         points[i][0] = input.nextDouble();
         points[i][1] = input.nextDouble();
      }
      Rectangle boundingRectangle = getRectangle(points);
      //Prints center, width, and height of bounding rectangle
      System.out.print("Center ("+(boundingRectangle.getXpos()+boundingRectangle.getWidth()/2.0)+","+(boundingRectangle.getYpos()+boundingRectangle.getHeight()/2.0)+"), ");
      System.out.println("Width "+boundingRectangle.getWidth()+", Height "+boundingRectangle.getHeight());
   }
   
   public static Rectangle getRectangle(double[][] points){
      Rectangle rect1 = new Rectangle(points[0][0],points[0][1],points[0][0],points[0][1]);
      //for loop to assign the xpos and ypos to the smallest of each value
      for (int i = 0; i < points.length; i++){
         if(points[i][0]<rect1.getXpos()) rect1.setXpos(points[i][0]);
         if(points[i][1]<rect1.getYpos()) rect1.setYpos(points[i][1]);
      }
      //for loop to assign width and height to the largest x,y coordinate of all points
      //Using width and height as place holders until later
      for(int i=0;i<points.length;i++){
         if(points[i][0]>rect1.getWidth()) rect1.setWidth(points[i][0]);
         if(points[i][1]>rect1.getHeight()) rect1.setHeight(points[i][1]);
      }
      //Calculating proper width and height
      rect1.setWidth(rect1.getWidth()-rect1.getXpos());
      rect1.setHeight(rect1.getHeight()-rect1.getYpos());
      return rect1;
   }
}
