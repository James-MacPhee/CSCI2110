//QuickSort Algorithm
//Recursively sorts an ArrayList of positive integers in ascending order
//The first item in each sub-array is selected as the pivot 
import java.util.Random;
import java.util.ArrayList;
public class Exercise2{
   
   static Random rn = new Random();
   
	public static <T extends Comparable<T>> void quickSort(ArrayList<T> list, int from, int to){
		int index = partition(list, from, to);
		if (from<index -1) quickSort(list,from, index-1);
		if (index<to) quickSort(list,index,to);
	}
	public static <T extends Comparable<T>> int partition(ArrayList<T> list, int left, int right){
		int i=left, j=right;
		T tmp;
      //int num = rn.nextInt(list.size()); ***I used this to get a random pivot, by changing 'i' in next line to 'num'
		T pivot=list.get(i); //pivot is the first element of the sub-array
		while(i<=j){
			while(list.get(i).compareTo(pivot)<0) i++;
			while(list.get(j).compareTo(pivot)>0) j--;
			if (i<=j){
				tmp=list.get(i);
				list.set(i,list.get(j));
				list.set(j,tmp);
				i++;
				j--;
			}
		}
		return i;
	}
	public static <T extends Comparable<T>> ArrayList<T> quickSort(ArrayList<T> list){
		quickSort(list, 0, list.size()-1);
		return list;
	}
	public static void main(String[] args){
      //I stored all the ArrayLists in an ArrayList
      ArrayList<ArrayList<Integer>> list = new ArrayList<ArrayList<Integer>>();
      ArrayList<Integer> result = new ArrayList<Integer>();
      //Adding ArrayLists
      for(int i=0;i<64;i++){
         ArrayList<Integer> temp = new ArrayList<Integer>();
         list.add(temp);
      }
		int num;
      
      long start = System.currentTimeMillis(); //Timer
      //Adding numbers to different ArrayLists
      for(int i=0;i<320000;i++){
			num = rn.nextInt(320000);
         int count = num/5000;
         list.get(count).add(num); //Using this to make sure num is added to proper ArrayList
		}
      //Adding all elements to final ArrayList
      for(int i=0;i<64;i++){
         quickSort(list.get(i));
         while(!list.get(i).isEmpty()) result.add(list.get(i).remove(0));
      }
      System.out.print(System.currentTimeMillis()-start); //Print timer
	}
}