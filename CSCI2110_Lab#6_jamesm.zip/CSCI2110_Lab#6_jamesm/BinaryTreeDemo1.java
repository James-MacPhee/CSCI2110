/* CSCI 2110 - Lab #6 - BinaryTreeDemo1

   This program creates a BinaryTree with each node containing user inputted Strings as data.

   James MacPhee - B00768516 - Oct.27th 2018 */
import java.util.Scanner;
import java.util.ArrayList;
public class BinaryTreeDemo1{
	public static void main(String[] args){
		
      Scanner sc = new Scanner(System.in);
      ArrayList<BinaryTree<String>> list = new ArrayList<BinaryTree<String>>();
      
      System.out.print("Enter name or Done: ");
      String input = sc.next();
      //Filling arraylist full of BinaryTree items
      while(!input.equals("Done")){
         BinaryTree<String> temp = new BinaryTree<String>();
         temp.setData(input);
         list.add(temp);
          System.out.print("Enter name or Done: ");
         input = sc.next();
      }
      BinaryTree<String> root = list.get(0);
      
      //Taking BinaryTrees from ArrayList and connecting together alternately left and right
      for(int i=0;i<list.size();i++){
         if((i*2)+1<list.size()){
            if(list.get((i*2)+1)!=null){
               list.get(i).attachLeft(list.get((i*2)+1));            
            }
         }
         if((i*2)+2<list.size()){
            if(list.get((i*2)+2)!=null){
               list.get(i).attachRight(list.get((i*2)+2));
            }
         }
      }
      
      System.out.print("Pre-order:\t");
		BinaryTree.preorder(root);
		System.out.println();
		      
		System.out.print("In-order:\t");
		BinaryTree.inorder(root);
		System.out.println();
		      
	   System.out.print("Post-order:\t");
	   BinaryTree.postorder(root);
	   System.out.println();
		      
      System.out.print("Level-order: ");
      BinaryTree.levelOrder(root);
      System.out.println();
            
  	   System.out.println("Number of nodes: "+root.size());
            
      System.out.println("Height of tree: "+root.height());
            
      if(root.heightBalanced()) System.out.println("Tree is balanced!");
      else System.out.println("Tree is unbalanced.");

   }
}
