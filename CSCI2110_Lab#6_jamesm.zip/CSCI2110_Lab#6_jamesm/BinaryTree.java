import java.util.ArrayList;
public class BinaryTree<T> {
	
   private T data;
	private BinaryTree<T> parent;
	private BinaryTree<T> left;
	private BinaryTree<T> right;
	
	public BinaryTree(){
		parent = left = right = null;
		data = null;
	}
	public void makeRoot(T data){
		if (!isEmpty()){
			System.out.println("Can't make root. Already exists");
		}
		else
			this.data = data;
	}
	public void setData(T data){
		this.data = data;
	}
	public void setLeft(BinaryTree<T> tree){
		left = tree;
	}
	public void setRight(BinaryTree<T> tree){
		right = tree;
	}
	public void setParent(BinaryTree<T> tree){
		parent = tree;
	}
	public T getData(){
		return data;
	}
	public BinaryTree<T> getParent(){
		return parent;
	}
	public BinaryTree<T> getLeft(){
		return left;
	}
	public BinaryTree<T> getRight(){
		return right;
	}
	public void attachLeft(BinaryTree<T> tree){
		if (tree==null) return;
		else if (left!=null || tree.getParent()!=null){
			System.out.println("Can't attach");
			return;
		}
		else{
				tree.setParent(this);
				this.setLeft(tree);
		}
	}
	public void attachRight(BinaryTree<T> tree){
		if (tree==null) return;
		else if (right!=null || tree.getParent()!=null){
			System.out.println("Can't attach");
			return;
		}
		else{
				tree.setParent(this);
				this.setRight(tree);
		}
	}
	public BinaryTree<T> detachLeft(){
		if (this.isEmpty()) return null;
		BinaryTree<T> retLeft = left;
		left = null;
		if (retLeft!=null) retLeft.setParent(null);
		return retLeft;
	}
	public BinaryTree<T> detachRight(){
		if (this.isEmpty()) return null;
		BinaryTree<T> retRight = right;
		right =null;
		if (retRight!=null) retRight.setParent(null);
		return retRight;
	}
   //Method to find number of nodes in a binary tree
   public int size(){
      int n=0;
      if(isEmpty()) return n;
      BinaryTree<T> right = getRight();
      BinaryTree<T> left = getLeft();
      if(right!=null) n += right.size();
      if(left!=null) n += left.size();
      return n+1;
   }
   //Method to find the height of a binary tree
   public int height(){
      int leftHeight=0;
      int rightHeight=0;
      int height=0;
      
      if(isEmpty()) return height;
      
      BinaryTree<T> right = getRight();
      BinaryTree<T> left = getLeft();
      if(right!=null) rightHeight += right.height();
      if(left!=null) leftHeight += left.height();
      
      if(rightHeight>leftHeight) return rightHeight+1;
      else return leftHeight+1;
   }
   //Method to find out whether a binary tree is height balanced or not
   public boolean heightBalanced(){
      int leftHeight=0;
      int rightHeight=0;
      
      if(isEmpty()) return true;
      
      BinaryTree<T> right = getRight();
      BinaryTree<T> left = getLeft();
      
      if(rightHeight-leftHeight>1 || leftHeight-rightHeight>1) return false;
      if(right!=null) rightHeight += right.height();
      if(left!=null) leftHeight += left.height();
      if(rightHeight-leftHeight>1 || leftHeight-rightHeight>1) return false;
      
      return true;
   }
	public boolean isEmpty(){
		if (data == null)
			return true;
		else
			return false;
	}
	public void clear(){
		left = right = parent =null;
		data = null;
	}
	public BinaryTree<T> root(){
		if (parent == null)
			return this;
		else{
			BinaryTree<T> next = parent;
			while (next.getParent()!=null)
				next = next.getParent();
			return next;
		}
	}
	public static <T> void preorder(BinaryTree<T> t){
		if (t!=null){
			System.out.print(t.getData()+"\t");
			preorder(t.getLeft());	
			preorder(t.getRight());
		}
	}
	public static <T> void inorder(BinaryTree<T> t){
		if (t!=null){
			inorder(t.getLeft());
			System.out.print(t.getData() + "\t");
			inorder(t.getRight());
		}
	}
	public static <T> void postorder(BinaryTree<T> t){
		if (t!=null){
			postorder(t.getLeft());
			postorder(t.getRight());
			System.out.print(t.getData() + "\t");
		}
	}
   //Method to perform an traverse operation like above three methods but level by level
   public static <T> void levelOrder(BinaryTree<T> tree){
      
      if(tree!=null){
         System.out.print(tree.root().getData());
         ArrayList<BinaryTree<T>> arr = new ArrayList<BinaryTree<T>>(); 
         
         while(!arr.isEmpty()){
            for(int j=0;j<arr.size();j++){
               BinaryTree<T> tmp = arr.get(j);
               arr.remove(tmp);
               arr.add(tmp.getLeft());
               arr.add(tmp.getLeft());
               
            }
            for(int i=0;i<arr.size();i++) System.out.print(arr.get(i).getData()+"\t");
         }
      }
   }
}