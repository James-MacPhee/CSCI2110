/* CSCI 2110 - Lab #6 - BinaryTreeDemo

   This program creates a BinaryTree according to user input.

   James MacPhee - B00768516 - Oct.27th 2018 */
import java.util.Scanner;
import java.util.ArrayList;
public class BinaryTreeDemo{
	public static void main(String[] args){
		
      Scanner sc = new Scanner(System.in);
      //Creating trees
      BinaryTree<String> A = new BinaryTree<String>();
		BinaryTree<String> B = new BinaryTree<String>();
		BinaryTree<String> C = new BinaryTree<String>();
		BinaryTree<String> D = new BinaryTree<String>();
		BinaryTree<String> E = new BinaryTree<String>();
		BinaryTree<String> F = new BinaryTree<String>();
      A.makeRoot("A");
		B.makeRoot("B");
		C.makeRoot("C");
		D.makeRoot("D");
		E.makeRoot("E");
		F.makeRoot("F");
		
      System.out.println("You have 6 single node Binary Trees named A-F to work with. 'A' will always be the root.");
      System.out.println("Enter the nodes you want to add to the root 'A' in order as they will be attached alternately left and right.");
      System.out.println("Example: You want the tree to be (A has chilren B-C in that order and B has children D-E while C has children F) then type in B C D E F.");
      System.out.println("You are allowed to enter null to skip a space.");
      int count=0;
      ArrayList<BinaryTree<String>> list = new ArrayList<BinaryTree<String>>();
      System.out.print("Enter your nodes in order now: ");
      list.add(A);
      //while loop to add item in proper order into arraylist
      while(count<5){
         String input = sc.next();
         if(input.equals("B")) list.add(B);
         else if(input.equals("C")) list.add(C);
         else if(input.equals("D")) list.add(D);
         else if(input.equals("E")) list.add(E);
         else if(input.equals("F")) list.add(F);
         count++;
      }
      //for loop to attach all nodes properly
      for(int i=0;i<list.size();i++){
         if((i*2)+1<list.size()){
            if(list.get((i*2)+1)!=null){
               list.get(i).attachLeft(list.get((i*2)+1));            
            }
         }
         if((i*2)+2<list.size()){
            if(list.get((i*2)+2)!=null){
               list.get(i).attachRight(list.get((i*2)+2));
            }
         }
      }
      
      
      System.out.print("Pre-order:\t");
		BinaryTree.preorder(A);
		System.out.println();
		
		System.out.print("In-order:\t");
		BinaryTree.inorder(A);
		System.out.println();
		
		System.out.print("Post-order:\t");
		BinaryTree.postorder(A);
		System.out.println();
		
      System.out.print("level-order:\t");
		BinaryTree.levelOrder(A);
		System.out.println();
      
      int n = A.size();
		System.out.println(n);
      
      int h = A.height();
      System.out.println(h);
      
      boolean b = A.heightBalanced();
      System.out.println(b);
	}
}