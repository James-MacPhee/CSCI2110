/* CSCI 2110 - Assignment #2 - TeamStats

   This program defines a list of NHL teams almost like a miniature league.

   James MacPhee - B00768516 - Oct.24th 2018 */
public class TeamStats{
   
   private List<Team> teamList;
   //Constructor
   public TeamStats(){
      
      teamList = new List<Team>();
      //The following block of lines simply creates all the NHL teams given in the link in the lab notes
      Team team = new Team("AFM");
      teamList.add(team);
      team = new Team("ANA");
      teamList.add(team);
      team = new Team("ARI");
      teamList.add(team);
      team = new Team("ATL");
      teamList.add(team);
      team = new Team("BOS");
      teamList.add(team);
      team = new Team("BFK");
      teamList.add(team);
      team = new Team("BUF");
      teamList.add(team);
      team = new Team("CAR");
      teamList.add(team);
      team = new Team("CGS");
      teamList.add(team);
      team = new Team("CGY");
      teamList.add(team);
      team = new Team("CHI");
      teamList.add(team);
      team = new Team("CBL");
      teamList.add(team);
      team = new Team("CLE");
      teamList.add(team);
      team = new Team("CLR");
      teamList.add(team);
      team = new Team("COL");
      teamList.add(team);
      team = new Team("DAL");
      teamList.add(team);
      team = new Team("DFL");
      teamList.add(team);
      team = new Team("DCG");
      teamList.add(team);
      team = new Team("DET");
      teamList.add(team);
      team = new Team("EDM");
      teamList.add(team);
      team = new Team("FLA");
      teamList.add(team);
      team = new Team("HAM");
      teamList.add(team);
      team = new Team("HFD");
      teamList.add(team);
      team = new Team("KCS");
      teamList.add(team);
      team = new Team("LAK");
      teamList.add(team);
      team = new Team("MIN");
      teamList.add(team);
      team = new Team("MMR");
      teamList.add(team);
      team = new Team("MNS");
      teamList.add(team);
      team = new Team("MTL");
      teamList.add(team);
      team = new Team("MWN");
      teamList.add(team);
      team = new Team("NSH");
      teamList.add(team);
      team = new Team("NJD");
      teamList.add(team);
      team = new Team("NYA");
      teamList.add(team);
      team = new Team("NYI");
      teamList.add(team);
      team = new Team("NYP");
      teamList.add(team);
      team = new Team("OAK");
      teamList.add(team);
      team = new Team("OTT");
      teamList.add(team);
      team = new Team("PHI");
      teamList.add(team);
      team = new Team("PHX");
      teamList.add(team);
      team = new Team("PIR");
      teamList.add(team);
      team = new Team("PIT");
      teamList.add(team);
      team = new Team("QUA");
      teamList.add(team);
      team = new Team("QUE");
      teamList.add(team);
      team = new Team("QBD");
      teamList.add(team);
      team = new Team("SEN");
      teamList.add(team);
      team = new Team("SJS");
      teamList.add(team);
      team = new Team("SLE");
      teamList.add(team);
      team = new Team("STL");
      teamList.add(team);
      team = new Team("TAN");
      teamList.add(team);
      team = new Team("TBL");
      teamList.add(team);
      team = new Team("TOR");
      teamList.add(team);
      team = new Team("TSP");
      teamList.add(team);
      team = new Team("VAN");
      teamList.add(team);
      team = new Team("VGK");
      teamList.add(team);
      team = new Team("WIN");
      teamList.add(team);
      team = new Team("WPG");
      teamList.add(team);
      team = new Team("WSH");
      teamList.add(team);
   }
   //Get method
   public List<Team> getList(){
      return teamList;
   }
   /*
     The following two methods work the same as the five methods in 'PlayerStats' class but with team variables instead of player
   */
   
   //Method to find the team with the highest number of total penalty minutes
   public void mostPIM(){
      Team curr = teamList.first();
      Team temp = teamList.next();
      for(int i=1;i<teamList.size();i++){
         if(temp.getTotalPIM()>curr.getTotalPIM()) curr = temp;
         temp = teamList.next();
      }
      temp = teamList.first();
      for(int i=1;i<teamList.size();i++){
         if(temp.getTotalPIM()==curr.getTotalPIM()) System.out.println(temp);
         temp = teamList.next();
      }
   }
   //Method to find the team with the highest number of game winning goals
    public void mostGWG(){
      Team curr = teamList.first();
      Team temp = teamList.next();
      for(int i=1;i<teamList.size();i++){
         if(temp.getTotalGWG()>curr.getTotalGWG()) curr = temp;
         temp = teamList.next();
      }
      temp = teamList.first();
      for(int i=1;i<teamList.size();i++){
         if(temp.getTotalGWG()==curr.getTotalGWG()) System.out.println(temp);
         temp = teamList.next();         
      }
   }
}