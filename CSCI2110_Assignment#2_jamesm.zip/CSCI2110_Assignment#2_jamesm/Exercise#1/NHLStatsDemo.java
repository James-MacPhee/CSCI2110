/* CSCI 2110 - Assignment #2 - NHLStatsDemo

   This program defines reads in player data from a file and populates teams accordingly.
   It then uses the different methods in the different classes to display information,
   about the teams and players of the league.

   James MacPhee - B00768516 - Oct.24th 2018 */
import java.io.*;
import java.util.Scanner;
public class NHLStatsDemo{
   public static void main(String[] args) throws IOException{
      
      //Following block of code changes the printstream to a file instead of console
      PrintStream out = new PrintStream(new FileOutputStream("nhlstatsoutput.txt"));
      System.setOut(out);
      
      //Following block sets input ready
		File file = new File("nhlstats.txt");
		Scanner inputFile = new Scanner(file);
		
      //Creating teams
      TeamStats teams = new TeamStats();
      
      //Creating players
		PlayerStats players = new PlayerStats();
      
      //All 17 of the instance variables for PLayerRecord
		String name,team;
      int gp,g,a,p,r,ppg,ppp,shg,shp,gwg,pim,sog,atoi;
      double ptsg,shper;
		PlayerRecord player=null;
		//While loop to create each player and fill with stats from the file
		while (inputFile.hasNext()){
			name = inputFile.nextLine();
			team = inputFile.nextLine();
			gp = Integer.parseInt(inputFile.nextLine());
         g = Integer.parseInt(inputFile.nextLine());
         a = Integer.parseInt(inputFile.nextLine());
         p = Integer.parseInt(inputFile.nextLine());
         r = Integer.parseInt(inputFile.nextLine());
         ppg = Integer.parseInt(inputFile.nextLine());
         ppp = Integer.parseInt(inputFile.nextLine());
         ptsg = Double.parseDouble(inputFile.nextLine());
         shg = Integer.parseInt(inputFile.nextLine());
         shp = Integer.parseInt(inputFile.nextLine());
         gwg = Integer.parseInt(inputFile.nextLine());
         pim = Integer.parseInt(inputFile.nextLine());
         sog = Integer.parseInt(inputFile.nextLine());
         shper = Double.parseDouble(inputFile.nextLine());
         String[] split = inputFile.nextLine().split(":"); //Reads the time as M:S format and splits it
         String time = split[0]+split[1]; //Concatenates minutes and seconds into one String
         atoi = Integer.parseInt(time);
         
			player = new  PlayerRecord(name,team,gp,g,a,p,r,ppg,ppp,ptsg,shg,shp,gwg,pim,sog,shper,atoi);
			players.add(player);
         
         //The following block populates the teams with the correct players
         Team temp = teams.getList().first();
         for(int i=0;i<teams.getList().size();i++){
            if(team.equals(temp.getName())) temp.add(player);
            temp = teams.getList().next();
         }
		}
		inputFile.close();
      
      //Now the program will make uses of the PlayerStats method to display the crowning players
      System.out.println("The player(s) with the most game winning goals:");
      players.mostGWG();
      System.out.println("\nThe player(s) with the highest average time on the ice:");
      players.mostATOI();
      System.out.println("\nThe player(s) with the most penalty minutes:");
      players.mostPIM();
      System.out.println("\nThe player(s) with the most shots on goal:");
      players.mostSOG();
      System.out.println("\nThe player(s) with the most assists:");
      players.mostA();
      System.out.println("\nThe team(s) with the most total game winning goals:");
      teams.mostGWG();
      System.out.println("\nThe team(s) with the most penalty minutes:");
      teams.mostPIM();
   }
}