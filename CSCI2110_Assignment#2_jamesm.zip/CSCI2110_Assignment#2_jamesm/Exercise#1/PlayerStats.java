/* CSCI 2110 - Assignment #2 - PlayerStats

   This program defines a list of NHL players and keep tracks of all their stats.

   James MacPhee - B00768516 - Oct.24th 2018 */
public class PlayerStats{
   
   private List<PlayerRecord> playerlist;
   
   public PlayerStats(){
      playerlist = new List<PlayerRecord>();
   }
   //Method to add a player's PlayerRecord to the list
   public void add(PlayerRecord player){
      playerlist.add(player);
   }
   //Get method
   public List<PlayerRecord> getList(){
      return playerlist;
   }
   /* 
     The following 5 methods all work the exact same except find a different variable.
     They all use a single for loop to iterate through every player and find the one with,
     the highest of whatver variable that method is looking for and then displays that player.
     It then uses a second for loop that displays every player with equally as high of that variable.
   */
   
   //Method to find the player with the most GWG
   public void mostGWG(){
      
      PlayerRecord curr = playerlist.first();
      PlayerRecord temp = playerlist.next();
      for(int i=1;i<playerlist.size();i++){
         if(temp.getGWG()>curr.getGWG()) curr = temp;
         temp = playerlist.next();
      }
      temp = playerlist.first();
      for(int i=1;i<playerlist.size();i++){
         if(temp.getGWG()==curr.getGWG()) System.out.println(temp);
         temp = playerlist.next();
      }
   }
   //Method to find the player with the most ATOI
   public void mostATOI(){
      
      PlayerRecord curr = playerlist.first();
      PlayerRecord temp = playerlist.next();
      for(int i=1;i<playerlist.size();i++){
         if(temp.getATOI()>curr.getATOI()) curr = temp;
         temp = playerlist.next();
      }
      temp = playerlist.first();
      for(int i=1;i<playerlist.size();i++){
         if(temp.getATOI()==curr.getATOI()) System.out.println(temp);
         temp = playerlist.next();
      }
   }
   //method to find the most aggressive player
   public void mostPIM(){
   
      PlayerRecord curr = playerlist.first();
      PlayerRecord temp = playerlist.next();
      for(int i=1;i<playerlist.size();i++){
         if(temp.getPIM()>curr.getPIM()) curr = temp;
         temp = playerlist.next();
      }
      temp = playerlist.first();
      for(int i=1;i<playerlist.size();i++){
         if(temp.getPIM()==curr.getPIM()) System.out.println(temp);
         temp = playerlist.next();
      }
   }
   //method to find the most promising player
   public void mostSOG(){
   
      PlayerRecord curr = playerlist.first();
      PlayerRecord temp = playerlist.next();
      for(int i=1;i<playerlist.size();i++){
         if(temp.getSOG()>curr.getSOG()) curr = temp;
         temp = playerlist.next();
      }
      temp = playerlist.first();
      for(int i=1;i<playerlist.size();i++){
         if(temp.getSOG()==curr.getSOG()) System.out.println(temp);
         temp = playerlist.next();
      }
   }
   //method to find the player with the most assists
   public void mostA(){
   
      PlayerRecord curr = playerlist.first();
      PlayerRecord temp = playerlist.next();
      for(int i=1;i<playerlist.size();i++){
         if(temp.getA()>curr.getA()) curr = temp;
         temp = playerlist.next();
      }
      temp = playerlist.first();
      for(int i=1;i<playerlist.size();i++){
         if(temp.getA()==curr.getA()) System.out.println(temp);
         temp = playerlist.next();
      }
   }

}