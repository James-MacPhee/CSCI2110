/* CSCI 2110 - Assignment #2 - Team

   This program defines an NHL team with it's players.

   James MacPhee - B00768516 - Oct.24th 2018 */
public class Team{
   
   private String name;
   private int totalGWG = 0;
   private int totalPIM = 0;
   List<PlayerRecord> players;
   
   //Constructor
   public Team(String name){
      players = new List<PlayerRecord>();
      this.name=name;
   }
   //Method to add a player to the team list of players
   //It also adds the players PIM and GWG tp the teams total
   public void add(PlayerRecord player){
         totalPIM += player.getPIM();
         totalGWG += player.getGWG();
         players.add(player);
   }
   //--- get and Set methods ---
   public String getName(){
      return name;
   }
   public void setName(String name){
      this.name=name;
   }
   public int getTotalGWG(){
      return totalGWG;
   }
   public int getTotalPIM(){
      return totalPIM;
   }
   //toString method
   public String toString(){
      return "Team Name: "+name;
   }
}