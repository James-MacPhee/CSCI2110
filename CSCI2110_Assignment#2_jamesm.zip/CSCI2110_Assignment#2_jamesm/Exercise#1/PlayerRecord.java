/* CSCI 2110 - Assignment #2 - PlayerRecord

   This program defines an NHL player and 17 of their stats.

   James MacPhee - B00768516 - Oct.24th 2018 */
public class PlayerRecord{
   
   private String name,team;
   private int GP,G,A,P,rating,PPG,PPP,SHG,SHP,GWG,PIM,SOG,ATOI;
   private double PTSG,SHPer;
   
   //Constructor
   public PlayerRecord(String name,String team, int gp,int g,int a,int p,int r,int ppg,int ppp,double ptsg,int shg,int shp,int gwg,int pim,int sog,double shper,int atoi){
      this.name=name;this.team=team;
      GP=gp;G=g;A=a;P=p;rating=r;PPG=ppg;PPP=ppp;SHG=shg;SHP=shp;GWG=gwg;PIM=pim;SOG=sog;ATOI=atoi;
      PTSG=ptsg;SHPer=shper;
   }
   //--- Get methods ---
   public String getName(){
      return name;
   }
   public String getTeam(){
      return team;
   }
   public int getGP(){
      return GP;
   }
   public int getG(){
      return G;
   }
   public int getA(){
      return A;
   }
   public int getP(){
      return P;
   }
   public int getRating(){
      return rating;
   }
   public int getPPG(){
      return PPG;
   }
   public int getPPP(){
      return PPP;
   }
   public int getSHG(){
      return SHG;
   }
   public int getSHP(){
      return SHP;
   }
   public int getGWG(){
      return GWG;
   }
   public int getPIM(){
      return PIM;
   }
   public int getSOG(){
      return SOG;
   }
   public int getATOI(){
      return ATOI;
   }
   public double getPTSG(){
      return PTSG;
   }
   public double getSHPer(){
      return SHPer;
   }
   //toString method
   public String toString(){
      return  "Name: "+name+" Team: "+team;
   }
}