/* CSCI 2110 - Assignment #2 - MergeLists

   This program takes two text files each containing a list of names as input.
   It takes those names and makes an OrderedList of those names for each file.
   Then it merges those two files together into a third OrderList using the two-finger walking method.

   James MacPhee - B00768516 - Oct.24th 2018 */
import java.io.*;
import java.util.Scanner;
public class MergeLists{
   
   //Method to merge two OrderedLists and return the merged list
   public static <String extends Comparable<String>> OrderedList<String> merge(OrderedList<String> list1,OrderedList<String> list2){
      
      OrderedList<String> list = new OrderedList<String>();
      //I don't know what the two-finger walking method is because I wasn't in class that week but this merges the lists together.
      //I could have also used pointers and moved them forward accordingly instead of just removing .first() every time but returns same list.
      while(!list1.isEmpty()&&!list2.isEmpty()){ 
         if(list1.first().compareTo(list2.first())<0){
            list.add(list1.first());
            list1.remove(0);
         }
         else if(list1.first().compareTo(list2.first())==0){
            list.add(list1.first());
            list1.remove(0);
            list2.remove(0);
         }
         else{
            list.add(list2.first());
            list2.remove(0);
         }
      }  
      return list;
   }
   //Main Method
   public static void main(String[] args) throws IOException{
   
      //Following code block delcares and initializes all nesseccary Scanners
      Scanner sc = new Scanner(System.in);
      System.out.print("Enter input file #1 name: ");
      File file1 = new File(sc.nextLine());
      System.out.print("Enter input file #2 name: ");
      File file2 = new File(sc.nextLine());
      Scanner inputFile1 = new Scanner(file1);
      Scanner inputFile2 = new Scanner(file2);
      
      //creating OrderedLists that will be needed for program
      OrderedList<String> list1 = new OrderedList<String>();  
      OrderedList<String> list2 = new OrderedList<String>();
      OrderedList<String> mergedList;
      
      //Populating first OrderedList
      while(inputFile1.hasNext()){
         list1.insert(inputFile1.nextLine());
      }
      //Displaying resulting lists 
      System.out.println("\nFirst OrderedList contents:");
      list1.enumerate();
      
      
      //Populating second OrderedList
      while(inputFile2.hasNext()){
         list2.insert(inputFile2.nextLine());
      }
      //Displaying resulting lists
      System.out.println("\nSecond OrderedList contents:");
      list2.enumerate();
      
      
      //Creating merged OrderedList
      mergedList = merge(list1,list2);
      //Displaying resulting list 
      System.out.println("\nMerged OrderedList contents:");
      mergedList.enumerate();
   }
}