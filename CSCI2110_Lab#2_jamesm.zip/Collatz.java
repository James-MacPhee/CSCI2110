/* CSCI 2110 - Lab #2 - Exercise #2

   This program takes a number 'n' and checks every number from 
   1 to n to find which one makes the longest Collatz sequence.

   James MacPhee - B00768516 - Sept.20th 2018 */
import java.util.Scanner;
public class Collatz{
   public static void main(String[] args){
      
      System.out.print("Enter number to start: ");
      long startTime, endTime, executionTime;
      startTime = System.currentTimeMillis();
      Scanner sc = new Scanner(System.in);
      
      long startNum=0;
      long length = 0;
      long num = sc.nextInt();
      for(int i=0;i<=num;i++){
         if(findCollatz(i)>length){
            startNum=i;
            length=findCollatz(i);
         }
      }
      System.out.print("Starting Number: "+startNum+"\tLength: "+length);   
      endTime = System.currentTimeMillis();
      executionTime = endTime - startTime;
      System.out.print("\nTime to Completion: "+executionTime);   
   }
   //Method to return length of the collatz sequence for inputted number.
   public static long findCollatz(long n){
      long counter=1;
      while(n>1){
         if(n%2==0) n=n/2;
         else n=3*n+1;
         counter++;
      }
      return counter;
   }
}