/* CSCI 2110 - Lab #2 - Exercise #1

   This program takes a number 'n' and finds the n'th prime number.

   James MacPhee - B00768516 - Sept.20th 2018 */
import java.util.Scanner;
public class Prime{
   public static void main(String[] args){
   
      Scanner sc = new Scanner(System.in);
      System.out.print("Enter which prime number to find: ");
      long n=sc.nextLong();
      long startTime, endTime, executionTime;
      startTime = System.currentTimeMillis();   
      long counter = 1;
      long tempPrime = 2;
      while(counter<n){
         tempPrime = findNextPrime(tempPrime);
         counter++;
      }
      System.out.print("The "+n+"'th Prime number is: "+tempPrime);
      endTime = System.currentTimeMillis();
      executionTime = endTime - startTime;
      System.out.print("\nExecution Time: "+executionTime);
   }
   //Method that return the first prime after the number passed in.
   public static long findNextPrime(long p){
      long temp = p+1;
      while(true){
         if(isPrime(temp)){
            break;
         }
         temp++;
      }
      return temp;
   }
   //Checks if the passed in number is a prime or not.
   public static boolean isPrime(long n){
       if(n%2==0) return false;
       for(int i=3;i<=Math.sqrt(n);i+=2){
           if(n%i==0) return false;
       }
       return true;
   }
}