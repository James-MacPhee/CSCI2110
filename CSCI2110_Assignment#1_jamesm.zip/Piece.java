/* CSCI 2110 - Assignement #1 - Piece

   This program defines a game piece to be used on a board.
   
   James MacPhee - B00768516 - Oct.2nd 2018 */
public class Piece{
   
   private String name;
   private String colour; 
   private Point position;

   public Piece(){ //Constructor
   }
   public Piece(String name,String colour,int xpos,int ypos){ //Constructor
      this.name = name; 
      this.colour = colour;
      position = new Point(xpos,ypos);
   }
   //---Get and Set Methods
   public String getName(){
      return name;
   }
   public void setName(String name){
      this.name=name;
   }
   public String getColour(){
      return colour;
   }
   public void setColour(String colour){
      this.colour=colour;
   }
   public Point getPosition(){
      return position;
   }
   public void setPosition(int xpos,int ypos){
      position = new Point(xpos,ypos);
   }
   //toString Method
   public String toString(){
      return name+""+colour;  
   }
   //Empty methods to stop errors when 'movePiece' is called on an empty spot on the board
   public void move(String str,int i){
   }
   public void move(String str){
   }
   public String getAtt(){
      return null;
   }
}
