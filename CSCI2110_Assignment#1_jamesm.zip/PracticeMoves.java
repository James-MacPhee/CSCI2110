import java.util.StringTokenizer;
import java.util.Scanner;
public class PracticeMoves{
   public static void main(String[] args){
      
      Board board = new Board();
      Scanner sc = new Scanner(System.in);
      StringTokenizer token;
      String input;
      //Runs until user enters 'exit'
      while(true){
         System.out.println("\nEnter a command (type help for details):");
         input = sc.next();
         if(input.equals("create")){
            token = new StringTokenizer(sc.nextLine()," ");
            if(token.countTokens()==2){
               board.addPiece(Integer.valueOf(token.nextToken()),Integer.valueOf(token.nextToken()));
            }
            else if(token.countTokens()==3){
               board.addPiece(Integer.valueOf(token.nextToken()),Integer.valueOf(token.nextToken()),token.nextToken());
            }
            else if(token.countTokens()==4){
               board.addPiece(Integer.valueOf(token.nextToken()),Integer.valueOf(token.nextToken()),token.nextToken(),token.nextToken());
            }
            else System.out.println("Error incorrect input.");
         }
         else if(input.equals("move")){
            token = new StringTokenizer(sc.nextLine()," ");
            if(token.countTokens()==3){
               board.movePiece(Integer.valueOf(token.nextToken()),Integer.valueOf(token.nextToken()),token.nextToken());
            }
            else if(token.countTokens()==4){
               board.movePiece(Integer.valueOf(token.nextToken()),Integer.valueOf(token.nextToken()),token.nextToken());
            }
            else System.out.println("Error incorrect input.");
         }
         else if(input.equals("print")){
            board.print();
         }
         else if(input.equals("help")){
            board.help();
         }
         else if(input.equals("exit")){
            board.exit();
         }
         else{
            System.out.println("Improper input. Please try again.");
         }
      }
   }
}