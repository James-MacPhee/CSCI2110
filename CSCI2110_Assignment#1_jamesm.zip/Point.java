/* CSCI 2110 - Assignement #1 - Point

   This program defines a simple point object that has an 'x' and a 'y' coordinate.
   
   James MacPhee - B00768516 - Oct.2nd 2018 */
public class Point{
   
   private int xpos;
   private int ypos;
   
   public Point(){ //Constructor
   }
   public Point(int xpos,int ypos){ //Constructor
      this.xpos=xpos;
      this.ypos=ypos;
   }
   //---Get and Set methods---
   public int getXpos(){
      return xpos;
   }
   public void setXpos(int xpos){
      this.xpos=xpos;
   }
   public int getYpos(){
      return ypos;
   }
   public void setYpos(int ypos){
      this.ypos=ypos;
   }
}
