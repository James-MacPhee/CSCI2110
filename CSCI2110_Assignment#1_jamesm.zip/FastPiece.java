/* CSCI 2110 - Assignement #1 - FastPiece

   This program creates a 'Piece' that is able to move multiple spot at a time,
   but only left and right.
   
   James MacPhee - B00768516 - Oct.2nd 2018 */
public class FastPiece extends Piece{
   
   private String attribute = "Fast"; //Attributes are to make sure only flexible pieces are moved up and down
   
   public String getAtt(){
      return attribute;
   }
   //Constructor
   public FastPiece(String name,String colour,int xpos,int ypos){
      super(name,colour,xpos,ypos);
   }
   //toString method
   public String toString(){
      return super.toString()+"F";
   }
   //Method to move a piece as many spaces as inputted/allowed
   public void move(String direction,int n){
      if(direction.toLowerCase().equals("right")&&super.getPosition().getXpos()+n<=7) super.getPosition().setXpos(super.getPosition().getXpos()+n);
      else if(direction.toLowerCase().equals("left")&&super.getPosition().getXpos()-n>=0) super.getPosition().setXpos(super.getPosition().getXpos()-n);
   } 
}
