/* CSCI 2110 - Assignement #1 - SlowPiece

   This program creates a 'Piece' but makes it only able to move one spot at a time,
   but only left and right.
   
   James MacPhee - B00768516 - Oct.2nd 2018 */
public class SlowPiece extends Piece{
   
   private String attribute = "Slow"; //Attributes are to make sure only flexible pieces are moved up and down
   
   public String getAtt(){
      return attribute;
   }
   public SlowPiece(String name,String colour,int xpos,int ypos){ //Constructor
      super(name,colour,xpos,ypos);
   }
   //toString method
   public String toString(){
      return super.toString()+"S";
   }
   //Method to move a piece one spot at a time
   public void move(String direction){
      if(direction.toLowerCase().equals("right")&&super.getPosition().getXpos()!=7) super.getPosition().setXpos(super.getPosition().getXpos()+1);
      else if(direction.toLowerCase().equals("left")&&super.getPosition().getXpos()!=0) super.getPosition().setXpos(super.getPosition().getXpos()-1);
   } 
}
