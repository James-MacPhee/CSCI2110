/* CSCI 2110 - Assignement #1 - FastFlexible

   This program creates a piece similar to 'FastPiece' but can also move up and down,
   and still as many spots as desired at a time.
   
   James MacPhee - B00768516 - Oct.2nd 2018 */
public class FastFlexible extends FastPiece {
   
   private String attribute = "FastFlexible"; //Attributes are to make sure only flexible pieces are moved up and down
   
   public FastFlexible(String name,String colour,int xpos,int ypos){ //Constructor
      super(name,colour,xpos,ypos);
   }
   public String getAtt(){
      return attribute;
   }
   //toString method
   public String toString(){
      return super.toString()+"F";
   }
   //Method to move the piece left, right, up, or down
   public void move(String direction,int n){
      if(direction.toLowerCase().equals("up")&&super.getPosition().getYpos()-n!=0) super.getPosition().setYpos(super.getPosition().getYpos()-n);
      else if(direction.toLowerCase().equals("down")&&super.getPosition().getYpos()+n!=7) super.getPosition().setYpos(super.getPosition().getYpos()+n);
      else super.move(direction,n);
   }
}