import java.util.Scanner;
import java.util.StringTokenizer;
public class Board{

   StringTokenizer token;
   Scanner sc = new Scanner(System.in);
   private Piece[][] board;
   
   //Constructor
   public Board(){
      board = new Piece[8][8];
   }
   //Method to add a FastFlexible piece to the board
   public void addPiece(int xpos,int ypos,String str1,String str2){
      if(board[xpos][ypos]==null){ //Makes sure spot isn't already occupied
         if((str1.equals("fast") && str2.equals("flexible")) || (str1.equals("flexible") && str2.equals("fast"))){
            System.out.println("Input a name for the new piece: ");
            String name = sc.next();
            System.out.println("Input a colour for the new piece: ");
            String colour = sc.next();
            FastFlexible piece = new FastFlexible(name,colour,xpos,ypos);
            board[ypos][xpos] = piece;
         }
         else System.out.println("Incorrect input.");
      }
      else{
         System.out.println("There is already a piece at ("+xpos+","+ypos+").");
      }
   }
   //Method to add either a SlowFlexible or a FastPiece to the board
   public void addPiece(int xpos,int ypos,String str){
      if(board[ypos][xpos]==null){ //Makes sure spot isn't already occupied
         if(str.equals("fast")){
            System.out.println("Input a name for the new piece: ");
            String name = sc.next();
            System.out.println("Input a colour for the new piece: ");
            String colour = sc.next();
            FastPiece piece = new FastPiece(name,colour,xpos,ypos);
            board[ypos][xpos] = piece;
         }
         else if(str.equals("flexible")){
            System.out.println("Input a name for the new piece: ");
            String name = sc.next();
            System.out.println("Input a colour for the new piece: ");
            String colour = sc.next();
            SlowFlexible piece = new SlowFlexible(name,colour,xpos,ypos);
            board[ypos][xpos] = piece;
         }
         
         else System.out.println("Incorrect input.");
      }
      else{
         System.out.println("There is already a piece at ("+xpos+","+ypos+").");
      }
   }
   //Method to add a SlowPiece to the board
   public void addPiece(int xpos,int ypos){
      if(board[ypos][xpos]==null){ //Makes sure spot isn't already occupied
         System.out.println("Input a name for the new piece: ");
         String name = sc.next();
         System.out.println("Input a colour for the new piece: ");
         String colour = sc.next();
         SlowPiece piece = new SlowPiece(name,colour,xpos,ypos);
         board[ypos][xpos] = piece;
      }
      else{
         System.out.println("There is already a piece at ("+xpos+","+ypos+").");
      }
   }
   //Method to move a FastPiece or FastFlexible at a desired location
   public void movePiece(int xpos,int ypos,String direction,int spaces){
      if(board[ypos][xpos]!=null && (board[ypos][xpos].getAtt().equals("Fast") || board[ypos][xpos].getAtt().equals("FastFlexible"))){
         if(direction.equals("left")) board[ypos][xpos].move("left",spaces);
         else if(direction.equals("right")) board[ypos][xpos].move("right",spaces);
         else if(direction.equals("up") && board[ypos][xpos].getAtt().equals("FastFlexible")) board[ypos][xpos].move("up",spaces);
         else if(direction.equals("down") && board[ypos][xpos].getAtt().equals("FastFlexible")) board[ypos][xpos].move("down",spaces);
         else System.out.println("Piece at desired spot is of incorrect type.");
      }
      else{
         System.out.println("Error: No piece at ("+xpos+","+ypos+")");
      }
   }
   //Method to move a SlowPiece or SlowFlexible at a desired location
   public void movePiece(int xpos,int ypos,String direction){
      if(board[ypos][xpos]!=null){
         if(board[ypos][xpos].getAtt().equals("SlowFlexible") || board[ypos][xpos].getAtt().equals("Slow")){
            if(direction.equals("left")) board[ypos][xpos].move("left");
            else if(direction.equals("right")) board[ypos][xpos].move("right");
            else if(direction.equals("up") && board[ypos][xpos].getAtt().equals("SlowFlexible")) board[ypos][xpos].move("up");
            else if(direction.equals("down") && board[ypos][xpos].getAtt().equals("SlowFlexible")) board[ypos][xpos].move("down");
            else System.out.println("Piece at desired spot is of incorrect type.");
         }
         else{
            if(direction.equals("left")){
               board[ypos][xpos].move("left",1);
               if(board[ypos][xpos].getPosition().getXpos()==xpos-1){
                  board[ypos][xpos-1] = board[xpos][ypos];
                  board[ypos][xpos] = null;
               }
            }
            else if(direction.equals("right")){
               board[ypos][xpos].move("right",1);
               if(board[ypos][xpos].getPosition().getXpos()==xpos+1){
                  board[ypos][xpos+1] = board[xpos][ypos];
                  board[ypos][xpos] = null;
               }
            }
            else if(direction.equals("up") && board[ypos][xpos].getAtt().equals("FastFlexible")){
               board[ypos][xpos].move("up",1);
               if(board[ypos][xpos].getPosition().getYpos()==ypos-1){
                  board[ypos-1][xpos] = board[xpos][ypos];
                  board[ypos][xpos] = null;
               }
            }
            else if(direction.equals("down") && board[ypos][xpos].getAtt().equals("FastFlexible")){
               board[ypos][xpos].move("down",1);
               if(board[ypos][xpos].getPosition().getYpos()==ypos+1){
                  board[ypos+1][xpos] = board[xpos][ypos];
                  board[ypos][xpos] = null;
               }
            }
            else System.out.println("Piece at desired spot is of incorrect type.");
         }
      }
      else{
         System.out.println("Error: No piece at ("+xpos+","+ypos+")");
      }
   }
   //Method to print the entire board
   public void print(){
      for(int i=0;i<8;i++){
         for(int j=0;j<8;j++){
            if(board[i][j]==null) System.out.print("-\t\t\t");
            else System.out.print(board[i][j]);
         }
         System.out.println();
      }
   }
   //Method to display the help menu
   public void help(){
      System.out.println("Possible commands are as follows:");
      System.out.println("\tcreate location [fast][flexible]: Creates a new piece.");
      System.out.println("\tmove location direction [spaces]: Moves a piece.");
      System.out.println("\tPrint: Displays the board.");
      System.out.println("\tHelp: Displays help.");
      System.out.println("\tExit: Exits the program.");
   }
   //Method for user to exit the program
   public void exit(){
      System.out.println("Done.");
      System.exit(0);
   }
}