/* CSCI 2110 - Assignement #1 - SlowFlexible

   This program creates a piece similar to 'SlowPiece' but can also move up and down,
   though still only one spot at a time.
   
   James MacPhee - B00768516 - Oct.2nd 2018 */
public class SlowFlexible extends SlowPiece {
   
   private String attribute = "SlowFlexible"; //Attributes are to make sure only flexible pieces are moved up and down
   
   public String getAtt(){
      return attribute;
   }
   public SlowFlexible(String name,String colour,int xpos,int ypos){ //Constructor
      super(name,colour,xpos,ypos);
   }
   //toString method
   public String toString(){
      return super.toString()+"F";
   }
   //Method to move the piece left, right, up, or down
   public void move(String direction){
      if(direction.toLowerCase().equals("up")&&super.getPosition().getYpos()!=0) super.getPosition().setYpos(super.getPosition().getYpos()-1);
      else if(direction.toLowerCase().equals("down")&&super.getPosition().getYpos()!=7) super.getPosition().setYpos(super.getPosition().getYpos()+1);
      else super.move(direction);
   }
}
