//CSCI2110 - Lab #8 - Exercise #2 
//*****
//This program uses HashMaps to simulate an application that,
//validates a user's login information for a web site
//*****
//B00768516 - Nov.23rd/2018
import java.util.HashMap;
import java.util.Scanner;
import java.io.*;

public class HashMapDemo{
	public static void main(String[] args) throws IOException{
      
		HashMap<String, String> loginInfo = new HashMap<String,String>();
      HashMap<String,String> names = new HashMap<String,String>();
		
      String password, username, fullname;
      Scanner keyboard = new Scanner(System.in);
		System.out.print("Enter the filename to read from: ");
		String filename = keyboard.nextLine();
		
		File file = new File(filename);
		Scanner inputFile = new Scanner(file);
		//Following loop gets user input for login info
		while (inputFile.hasNext()){
         fullname = inputFile.next()+" "+inputFile.next();
         username = inputFile.next();  
			password = inputFile.next();
			loginInfo.put(username, password);
         names.put(username,fullname);
		}
		
		inputFile.close();
		System.out.print("Login: ");
      String tempLog = keyboard.next();
		System.out.print("Password: ");
      String tempPass = keyboard.next();
      int i;
      //This loop keeps going until the login Info matches or it fails three times
      for(i=2;i>0;i--){
         if(loginInfo.containsKey(tempLog)){ //Tests if username matches
            if(loginInfo.get(tempLog).equals(tempPass)) break; //Tests if password matches
            else System.out.println("\nEither the username or password is incorrect. You have "+i+" more attempts.");
         }
         else System.out.println("\nEither the username or password is incorrect. You have "+i+" more attempts.");
         System.out.print("Login: ");
         tempLog = keyboard.next();
		   System.out.print("Password: ");
         tempPass = keyboard.next();
      }
      //Used to check if prvious loop failed all three times
      if(i==0){
         System.out.print("\nSorry. Incorrect login. Please contact the system administrator.");
		   System.exit(0);
      }
      System.out.print("\nLogin successful\nWelcome "+names.get(tempLog));
	}
}