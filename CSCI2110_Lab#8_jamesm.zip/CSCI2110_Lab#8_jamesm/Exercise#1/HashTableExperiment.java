//Hash Table Experiment
//This is a simple demo program that
//creates an ArrayList of LinkedList of Integer objects
//It first displays the empty linked lists
//It then hashes some keys and displays the linked lists again
//It uses the generic LinkedList class and the generic Node class
//*****
//CSCI2110 - Lab#8 - Exercise #1
//James MacPhee - B00768516 - Nov.23rd/2018
import java.util.Random;
import java.util.ArrayList;
import java.util.Scanner;
public class HashTableExperiment{
	public static void main(String[] args){
		
      //Creating random number generator
      Random rn = new Random();
      
      //prompt the user to enter the table size
		Scanner keyboard = new Scanner(System.in);
		System.out.print("Enter the hash table size: ");
		int n = keyboard.nextInt();
		
		//create an Arraylist of size n
		//The ArrayList holds a LinkedList object 
		//The LinkedList consists of nodes that hold integer objects
		ArrayList<LinkedList<Integer>> hashtable = new ArrayList<LinkedList<Integer>>();
		for (int i=0; i<n; i++){
			hashtable.add(i, new LinkedList<Integer>());
		}
		//Display the arraylist of linked lists
		System.out.println("Empty lists");
		for (int i=0; i<n; i++){
			System.out.print(i + ": ");
			hashtable.get(i).enumerate();
		}
      //Adding a user-defined amount of random keys to the hash-table
      System.out.print("\nPlease enter number of keys to be hashed: ");
      int i=0, num = keyboard.nextInt();
      ArrayList<Integer> keys = new ArrayList<Integer>();
      while(i<num){
         int temp = rn.nextInt(10000)+1;
         if(!keys.contains(temp)){
            keys.add(temp);
            i++;
         }
      }
      for(i=0;i<keys.size();i++){
         int temp = keys.get(i);
         int pos = temp%n;
         hashtable.get(pos).add(temp);
      }
			
		//Display the arraylist of linked lists
		System.out.println("\nAfter the keys are hashed");
		for (i=0; i<n; i++){
			System.out.print(i + ": ");
			hashtable.get(i).enumerate();
		}
      
      //Calculating number of collisions and longest list length
      int count=0;
      int max=0;
      for(i=0;i<hashtable.size();i++){
         if(hashtable.get(i).size()>max) max = hashtable.get(i).size();
         if(hashtable.get(i).size()>1) count += (hashtable.get(i).size()-1);
      }
      System.out.println("\nStatistics:");
      System.out.println("Table size: "+n);
      System.out.println("Number of keys: "+num);
      System.out.println("Load Factor: "+num/n);   
      System.out.println("Number of collisions: "+count);
      System.out.println("Longest LinkedList: "+max);
	}
}	