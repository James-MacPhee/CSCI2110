/* CSCI 2110 - Lab #7 - BinarySearchTreeDemo 

   This program creates and manipulates 2 BinarySearchTrees and tests their various methods. 

   James MacPhee - B00768516 - Nov.4th 2018 */
import java.util.Random;
import java.util.Scanner;
import java.io.*;
public class BinarySearchTreeDemo{
   public static void main(String[] args) throws IOException{
   
      Scanner sc = new Scanner(System.in);
      Random rn = new Random();
      
      //BLOCK 1
      BinarySearchTree<Integer> tree = new BinarySearchTree<Integer>();
      for(int i=0;i<10;i++){
         tree.insert(rn.nextInt(1000)+1);
      }
      
      System.out.print("Here are the keys in order: ");
      tree.inorder(tree.getTree());
      System.out.println("\nMinimum key value: "+tree.findMin());
      System.out.println("Maximum key value: "+tree.findMax());
      System.out.print("Enter a key you would like to search for: ");
      
      if(tree.recursiveSearch(sc.nextInt())!=null) System.out.println("Key was found.");
      else System.out.println("Key was NOT found");
      
      
      
      //BLOCK 2
      File file = new File("Output.txt");
      PrintStream out = new PrintStream(new FileOutputStream(file));
      System.setOut(out);
      
      int counter=0;
      while(counter<50){
         BinarySearchTree<Integer> tree2 = new BinarySearchTree<Integer>();
         for(int i=0;i<100;i++){
            tree2.insert(rn.nextInt(1000)+1);
         }
         
         System.out.println("Height: "+tree2.height());
         if(tree2.heightBalanced()) System.out.println("Tree is height balanced.");
         else System.out.println("Tree is NOT height balanced.");
         counter++;
      }
   }  
}