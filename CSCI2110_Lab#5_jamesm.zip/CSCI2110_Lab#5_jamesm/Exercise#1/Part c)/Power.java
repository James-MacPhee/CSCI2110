/* CSCI 2110 - Lab #5 - Exercise #1c

   This program uses simple recursion to calculate the equation x^n,
   where x and n are user-inputted numbers.

   James MacPhee - B00768516 - Oct.20th 2018 */
import java.util.Scanner;
public class Power{
   
   public static int power(int x,int n){
      if(n==0) return 1; //Base case
      else if(n>0) return x*power(x,n-1); //recursion
      else return 0; 
   }
   public static void main(String[] args){
      Scanner sc = new Scanner(System.in);
      //Here I couldn't figure out how to make sure no stack-overflow happened. 
      //I controlled the case where it causes negative values but not the ones that go past zero again.
      System.out.println("Enter an 'x' and an 'n' (Please don't use numbers that cause stack overflow)");
      int x=sc.nextInt(),n=sc.nextInt();
      if(power(x,n)>0) System.out.println(power(x,n));
      else System.out.println("Power too large for int type!");
   }
}