/* CSCI 2110 - Lab #5 - Exercise #1a

   This program uses simple arithemetic to determine a numbers
   factorial and then uses the numbers 1-10 as an example.

   James MacPhee - B00768516 - Oct.20th 2018 */
public class Factorial{
   
   //Method to find factorial of inputted number
   public static int factorial(int num){
      if(num==0) return 1; //Base case
      else return num*factorial(num-1); //recursion
   }
   //Main method to print out first 10 factorials
   public static void main(String[] args){
      for(int i=1;i<11;i++){
         System.out.println(factorial(i));
      }
   }
}