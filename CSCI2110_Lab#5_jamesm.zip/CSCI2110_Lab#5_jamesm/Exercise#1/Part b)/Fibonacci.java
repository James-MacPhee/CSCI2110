/* CSCI 2110 - Lab #5 - Exercise #1b

   This program uses simple arithemetic to determine the n'th
   number of the fibonacci sequence using recursion.

   James MacPhee - B00768516 - Oct.20th 2018 */
public class Fibonacci{
   
   public static int fib(int n){
      if(n==0) return 0; //Base case
      else if(n==1) return 1; //Base case
      else return fib(n-1)+fib(n-2); //recursion
   }
   //main method to test fib() method for first 20 numbers
   public static void main(String[] args){
      for(int i=0;i<20;i++){
         System.out.println(fib(i));
      }
   }
}