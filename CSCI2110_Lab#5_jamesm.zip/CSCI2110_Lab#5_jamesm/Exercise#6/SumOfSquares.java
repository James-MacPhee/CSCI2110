/* CSCI 2110 - Lab #5 - Exercise #6

   This program uses recursion to calculate and display the sums of squares,
   of every integer preceeding the inputted integer starting at 1.

   James MacPhee - B00768516 - Oct.20th 2018 */
import java.util.Scanner;
public class SumOfSquares{
   
   public static int SumOfSquares(int x){
      if(x>0){ 
         x = x*x+SumOfSquares(x-1); //Recursion
      }
      return x;
   }
   //Main method
   public static void main(String[] args){
   
      Scanner sc = new Scanner(System.in);
      System.out.println("Please enter a number ");
      System.out.print(SumOfSquares(sc.nextInt()));
   }
}