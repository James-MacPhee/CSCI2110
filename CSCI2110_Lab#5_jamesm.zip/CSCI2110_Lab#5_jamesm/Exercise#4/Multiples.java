/* CSCI 2110 - Lab #5 - Exercise #4

   This program uses recursion to find 'm' multiples of 'n' for some user-inputted m and n.

   James MacPhee - B00768516 - Oct.20th 2018 */
import java.util.Scanner;
public class Multiples{

   public static void multiples(int n,int m){
      
      if(m>1) multiples(n,m-1); //Recursion
      System.out.print(n*m+" "); 
   }
   //Main method
   public static void main(String[] args){
      
      Scanner sc = new Scanner(System.in);      
      System.out.print("Please enter two numbers: ");
      multiples(sc.nextInt(),sc.nextInt());
   }
} 