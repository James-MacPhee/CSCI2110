/* CSCI 2110 - Lab #5 - Exercise #7

   This program uses recursion to find the number of steps and execution
   time for Towers of Hanoi problem of user-inputted size 'n'.

   James MacPhee - B00768516 - Oct.20th 2018 */
import java.util.Scanner;
public class TowersOfHanoi{
   
   public static void Hanoi(int n,int from,int to,int temp){
      
      if(n>0){
         Hanoi(n-1,from,temp,to); //Recursion!
         Hanoi(n-1,temp,to,from); //Double Recursion!!
      }
   }
   public static void main(String[] args){
      
      Scanner sc = new Scanner(System.in);
      System.out.println("Please enter a number of discs: ");
      int n = sc.nextInt();
      //Only timing the actual recursion part
      long startTime, endTime, executionTime;
      startTime = System.currentTimeMillis();
      
      Hanoi(n,1,3,2);
      
      endTime = System.currentTimeMillis();
      executionTime = endTime - startTime;
      System.out.println("Num. of steps: "+((int)Math.pow(2,n)-1)); //Calculates the number of moves
      System.out.print("Execution Time: "+executionTime+"sec");
   }
}