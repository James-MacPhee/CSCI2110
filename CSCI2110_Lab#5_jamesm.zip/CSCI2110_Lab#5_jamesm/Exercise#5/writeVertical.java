/* CSCI 2110 - Lab #5 - Exercise #5

   This program uses recursion to take a user-inputted integer,
   and print it vertically with one digit on each new line.

   James MacPhee - B00768516 - Oct.20th 2018 */
import java.util.Scanner;
public class writeVertical{
   
   public static void writeVertical(int x){
      if(x>0){ 
         String str = Integer.toString(x); //Converts inputted integer to String
         int length = str.length(); 
         if(length>0){
            int last = Integer.valueOf(str.substring(length-1)); //Saves last digit of inutted integer
            if(length>1){
               int first =  Integer.valueOf(str.substring(0,length-1)); //Gets remaining number without 'last' to pass into method again
               writeVertical(first); //Recursion
            }
            System.out.println(last);
         }
      }
   }
   //Main method
   public static void main(String[] args){
   
      Scanner sc = new Scanner(System.in);
      System.out.println("Please enter a number to write vertically: ");
      writeVertical(sc.nextInt());
   }
}