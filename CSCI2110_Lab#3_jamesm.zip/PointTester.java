/* CSCI 2110 - Lab #3 - Exercise #1

   This program asks the user to input dimensions and then prints them out. 

   James MacPhee - B00768516 - Sept.29th 2018 */
import java.util.Scanner;
public class PointTester{
   public static void main(String[] args){
      
      Scanner sc = new Scanner(System.in);
      System.out.print("Enter point dimensions as integers: ");
      //Creating integer point
      Point<Integer> point1 = new Point<Integer>(sc.nextInt(),sc.nextInt());
      System.out.print("Enter point dimensions as doubles: ");
      //Creating double point
      Point<Double> point2 = new Point<Double>(sc.nextDouble(),sc.nextDouble());
      System.out.print("Enter point dimensions as strings: ");
      //Creating String point
      Point<String> point3 = new Point<String>(sc.next(),sc.next());
      System.out.println(point1);
      System.out.println(point2);
      System.out.println(point3);
   }
}