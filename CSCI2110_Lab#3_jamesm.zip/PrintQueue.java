/* CSCI 2110 - Lab #3 - Exercise #5

   This program defines a printQueue object and its methods

   James MacPhee - B00768516 - Sept.29th 2018 */
public class PrintQueue{
   
   private Job job = new Job();
   private GenericQueue<Job> queue;
   //Constructor
   public PrintQueue(){
      queue = new GenericQueue<Job>();
   }
   //Adds new job to queue
   public void lpr(String owner, int jobID){
      Job job = new Job(owner,jobID);
      queue.enqueue(job);
   }
   //Prints contents of queue
   public void lpq(){
      queue.setIterator(0);
      int temp = queue.size();
      System.out.println("\nAll print jobs:");
      for(int i=0;i<temp;i++){
         System.out.println(queue.next());
      }
      queue.setIterator(0);
   }
   //Removes certain print job
   public void lprm(int jobId){
      if(queue.peek() != null){
         if(queue.peek().getJobId() == jobId){
            queue.dequeue();
         }
      }
      else System.out.println("jobID isn't correct.");
   }
   //Removes all print jobs under the owners name
   public void lprmAll(String owner){
      int temp = queue.size();
      if(queue.peek() != null){
         if(queue.peek().getOwner()==owner){
            queue.remove(queue.peek());
         }
      }
      queue.setIterator(0);
      for(int i=0;i<temp;i++){
         if(queue.next().getOwner()==owner){
            queue.setIterator(i-1);
            queue.remove(queue.next());
         }
      }
   }
   //returns genericqueue
   public GenericQueue<Job> getQueue(){
      return queue;
   }
}