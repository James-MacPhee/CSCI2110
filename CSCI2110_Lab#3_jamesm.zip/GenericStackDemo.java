/* CSCI 2110 - Lab #3 - Exercise #2

   This program creates an instance of and tests the GenericStack class using two different variable types
   
   James MacPhee - B00768516 - Sept.29th 2018 */
import java.util.Scanner;
import java.util.ArrayList;
public class GenericStackDemo{
   public static void main(String[] args){
   
      Scanner sc = new Scanner(System.in);
      //String stack portion
      GenericStack<String> stack1 = new GenericStack<String>(); //Creates GenericStack object
      System.out.println("String Stack:");
      System.out.print("Enter a word (quit to end): ");
      String word = sc.next();
      //This chunk will keep taking user input until the user decides to stop
      if(!word.equals("quit")) stack1.push(word);
      while(!word.equals("quit")){
         System.out.print("Enter a word (quit to end): ");
         word = sc.next();
         if(!word.equals("quit")) stack1.push(word); //Makes sure not to add 'quit' to the stack
      }
      //Integer stack portion
      GenericStack<Integer> stack2 = new GenericStack<Integer>(); //Creates GenericStack object
      System.out.println("\nInteger Stack:");
      System.out.print("Enter a positive integer (negatives won't be added | -1 to end): ");
      int num = sc.nextInt();
      //This chunk will keep taking user input until the user decides to stop
      if(num>0) stack2.push(num);
      //I choose to not include zero as a positive integer
      while(num!=-1){
         System.out.print("Enter a positive integer (negatives won't be added | -1 to end): ");
         num = sc.nextInt();
         if(num>0) stack2.push(num); //Makes sure not to add '-1' to the stack
      }
      //Printing String stack
      System.out.println("\nString Stack Contents:");
      if(stack1.isEmpty()) System.out.println("You have to fill the stack before it will contain something, silly."); //It would still run fine without this of course
      //created temp variable to stop .getSize() to affect the number of iterations because it keeps lowering as elements are removed
      int temp = stack1.getSize();
      for(int i=0;i<temp;i++){
         System.out.println(stack1.pop());
      }
      //Printing integer stack
      temp = stack2.getSize();
      System.out.println("\nInteger Stack Contents:");
      if(stack2.isEmpty()) System.out.println("You have to fill the stack before it will contain something, silly."); //It would still run fine without this of course
      for(int i=0;i<temp;i++){
         System.out.println(stack2.pop());
      }
   }
}