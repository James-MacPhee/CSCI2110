/* CSCI 2110 - Lab #3 - Exercise #3

   This program creates a Stack data strcture full of StudentRecord objects and utilizes methods from both classes

   James MacPhee - B00768516 - Sept.29th 2018 */
import java.util.Scanner;
import java.io.*;
import java.util.StringTokenizer;
public class Exercise3{
   public static void main(String[] args)throws IOException{
      
      //Create and initialize first Stack
      GenericStack<StudentRecord> stack1 = new GenericStack<StudentRecord>();
      Scanner keyboard = new Scanner(System.in);
      System.out.print("Enter the filename to read from: ");
      String filename = keyboard.nextLine();
      //The next chunk uses tokenizers to read an input file line by line
      File file = new File(filename);
      Scanner inputFile = new Scanner(file);
      StringTokenizer token;
      while(inputFile.hasNext()){
         String line = inputFile.nextLine();
         token = new StringTokenizer(line, " ");
         String firstName = token.nextToken();
         String lastName = token.nextToken();
         String IDString = token.nextToken();
         Integer IDNum = Integer.valueOf(IDString);
         //The above statement converts the String IDString into the Integer object IDNum
         
         StudentRecord stu = new StudentRecord(firstName,lastName,IDNum);
         stack1.push(stu);
      }
      inputFile.close();
      //Creates second stack of just last names
      GenericStack<StudentRecord> stack2 = new GenericStack<StudentRecord>();
      int temp = stack1.getSize();
      for(int i=0;i<temp;i++){
         StudentRecord tempStu = new StudentRecord();
         tempStu.setLastName(stack1.pop().getLastName());
         stack2.push(tempStu);
      }
      for(int i=0;i<temp;i++) System.out.println(stack2.pop()); //Printing stack2
   }
}