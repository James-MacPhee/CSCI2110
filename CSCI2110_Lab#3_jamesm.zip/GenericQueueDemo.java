/* CSCI 2110 - Lab #3 - Exercise #4

   This program creates an instance of and tests the GenericQueue class using two different variable types.

   James MacPhee - B00768516 - Sept.29th 2018 */
import java.util.Scanner;
public class GenericQueueDemo{
   public static void main(String[] args){
      
      Scanner sc = new Scanner(System.in);
      //String queue portion
      GenericQueue<String> queue1 = new GenericQueue<String>();
      System.out.println("String Queue:");
      System.out.print("Enter a word (quit to end): ");
      String word = sc.next();
      //This chunk will keep taking user input until the user decides to stop
      if(!word.equals("quit"))queue1.enqueue(word);
      //
      while(!word.equals("quit")){
         System.out.print("Enter a word (quit to end): ");
         word = sc.next();
         if(!word.equals("quit")) queue1.enqueue(word); //Makes sure to not add the word 'quit' to the stack
      }
      //Integer queue portion
      GenericQueue<Integer> queue2 = new GenericQueue<Integer>();
      System.out.println("\nInteger Queue:");
      System.out.print("Enter a positive integer (negatives won't be added | -1 to end): ");
      int num = sc.nextInt();
      if(num>0) queue2.enqueue(num);
      //I choose to not include zero as a positive integer
      while(num!=-1){
         System.out.print("Enter a positive integer (negatives won't be added | -1 to end): ");
         num = sc.nextInt();
         if(num>0) queue2.enqueue(num);
      }
      //Printing String queue
      System.out.println("\nString Queue Contents:");
      if(queue1.isEmpty()) System.out.println("You have to fill the queue before it will contain something, silly."); //It would still run fine without this of course
      else{
         int temp1 = queue1.size(); //Makes sure that the number the iterator 'i' doesn't decrease as the loop is going
         for(int i=0;i<temp1;i++){
            System.out.println(queue1.dequeue());
         }
      }
      //Printing integer queue
      System.out.println("\nInteger Queue Contents:");
      if(queue2.isEmpty()) System.out.println("You have to fill the queue before it will contain something, silly."); //It would still run fine without this of course
      else{
         int temp2 = queue2.size(); //Makes sure that the number the iterator 'i' doesn't decrease as the loop is going
         for(int i=0;i<temp2;i++){
            System.out.println(queue2.dequeue());
         }
      }
   }
}