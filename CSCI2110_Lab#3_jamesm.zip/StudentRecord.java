/* CSCI 2110 - Lab #3 - Exercise #3

   This program defines a Stack data strcture full of StudentRecord objects and includes some simple methods

   James MacPhee - B00768516 - Sept.29th 2018 */
public class StudentRecord{
   
   private String firstName,lastName;
   private int bannerID;
   //Empty constructor
   public StudentRecord(){
   }
   //Constructor
   public StudentRecord(String fName,String lName,int ID){
      firstName=fName; lastName=lName; bannerID=ID;
   }
   //--- Get & Set methods ---
   public String getFirstName(){
      return firstName;
   }
   public void setFirstName(String fName){
      firstName=fName;
   }
   public String getLastName(){
      return lastName;
   }
   public void setLastName(String lName){
      lastName=lName;
   }
   public int getBannerID(){
      return bannerID;
   }
   public void setBannerID(int ID){
      bannerID=ID;
   }//toString method
   public String toString(){
      if (firstName ==null&&bannerID==0) return "Last Name: "+lastName; //changes the printing format so it doesn't print out null and 0 on stack2
      else return "First Name: "+firstName+"\tLast Name:"+lastName+"\tBannerID: "+bannerID;
   }
}