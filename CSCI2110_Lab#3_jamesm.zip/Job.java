/* CSCI 2110 - Lab #3 - Exercise #5

   This program defines a job to be used in the printQueue class

   James MacPhee - B00768516 - Sept.29th 2018 */
public class Job{
   
   private String owner;
   private int jobId;
   
   public Job(){
   }
   public Job(String o, int j){
      owner = o;
      jobId = j;
   }
   public String getOwner(){
      return owner;
   }
   public int getJobId(){
      return jobId;
   }
   public String toString(){
      return "Owner: "+owner+"\tJob ID: "+jobId;
   }
}