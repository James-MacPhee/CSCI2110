/* CSCI 2110 - Lab #3 - Exercise #2

   This program defines a Stack data structure (using ArrayLists to implement) that utilizes generics.

   James MacPhee - B00768516 - Sept.29th 2018 */
import java.util.ArrayList;
public class GenericStack<T> {
   
   private ArrayList<T> stack = new ArrayList<T>();
   private int counter=0;
   //Constructor
   public GenericStack(){
   }
   //Returns number of elements in the Stack
   public int getSize(){
      return stack.size();
   }
   //Returns the first element in the Stack
   public T peek(){
      return stack.get(0);
   }
   //Returns the first element in the Stack and thus removing it
   public T pop(){
      T pop = stack.get(0);
      stack.remove(0);
      return pop;
   }
   //Adds element to top of Stack (or front of ArrayList)
   public void push(T element){
      stack.add(0,element);
      counter++;
   }
   //Returns whether or not the Stack is empty
   public boolean isEmpty(){
      return stack.isEmpty();
   }
}