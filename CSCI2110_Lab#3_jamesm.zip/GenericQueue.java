/* CSCI 2110 - Lab #3 - Exercise #4

   This program defines a Queue data structure (using ArrayLists to implement) that utilizes generics.

   James MacPhee - B00768516 - Sept.29th 2018 */
import java.util.ArrayList;
public class GenericQueue<T>{
   
   private ArrayList<T> queue;
   private int iterator = 0;
   //Constructor
   public GenericQueue(){
      queue = new ArrayList<T>();
   }
   //Adds element to end of queue
   public void enqueue(T item){
      queue.add(item);
   }
   //Returns element in front of queue then removes it from queue
   public T dequeue(){
      T temp = queue.get(0);
      queue.remove(0);
      return temp;
   }
   //Sets the iterator for the arraylist
   public void setIterator(int i){
      iterator=i;
   }
   //Returns size of queue
   public int size(){
      return queue.size();
   }
   //Returns whether or not the queue is empty
   public boolean isEmpty(){
      return queue.isEmpty();
   }
   //Removes all elements from queue
   public void clear(){
      queue.clear();
   }
   //Returns element in front of queue
   public T peek(){
      if(queue.isEmpty()) return null;
      else return queue.get(0);
   }
   //Returns index of element passed in
   public int positionOf(T item){
      return queue.indexOf(item);
   }
   //Removes first occurence of item passed in
   public void remove(Job job){
      queue.remove(job);
   }
   //Returns the first item in the queue
   public T first(){
      iterator=1;
      if(queue.isEmpty()) return null;
      else return queue.get(0);
   }
   //returns the next item in the queue relative to the last call to next/first
   public T next(){
      iterator++;
      if(queue.isEmpty()){
         iterator--;
         return null;
      }
      else return queue.get(iterator-1);
   }
}