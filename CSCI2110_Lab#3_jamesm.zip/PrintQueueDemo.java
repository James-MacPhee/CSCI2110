/* CSCI 2110 - Lab #3 - Exercise #5

   This program creats an instance of the PrintQueue class and test its methods

   James MacPhee - B00768516 - Sept.29th 2018 */
import java.util.Random;
import java.util.Scanner;
public class PrintQueueDemo{
   public static void main(String[] args){
      
      PrintQueue pq = new PrintQueue();
      Scanner sc = new Scanner(System.in);
      Random rn = new Random(); //I choose to randomly generate jobID to add ease for user
      int counter = 0; //Using counter to make sure to not ask for name twice on first iteration
      String owner = "Placeholder";
      //Loops until user wants to quit
      while(!owner.equals("stop")){
         
         System.out.print("\nEnter your name (stop to quit): ");
         owner = sc.nextLine();
         if(counter>0) owner = sc.nextLine();
         if(owner.equals("quit")) System.exit(0);
         counter++;
         System.out.println("Hello "+owner+"! Enter 1 to add a print job, 2 to print all entries in queue, 3 to remove a the first print job in the queue, 4 to remove all of your print jobs, and 5 to quit.");
         int input = sc.nextInt();
         //'if else' statements to determine which action the user wants
         if(input==1){
            int jobID = rn.nextInt(899)+100;
            pq.lpr(owner,jobID);
            System.out.println("Thank you, your jobID is "+jobID+".");
         }
         else if(input==2){
            pq.lpq();
         }
         else if(input==3){
            System.out.println("Please enter jobID of print job: ");
            pq.lprm(sc.nextInt());
         }
         else if(input==4){
            
            pq.lprmAll(owner);
            System.out.println("All your print jobs have been removed.");
         }
         else if(input==5){
            System.out.println("Good bye "+owner);
            System.exit(0);
         }
         else System.out.println("Incorrect input, restart process please.");
      }
   }
}