/* CSCI2110 - Lab#4 - StudentListDemo

   Program reads a text file containing a list of countries and their capitals.
   File contains a country on a line and its capitakl on the next line.
   Program then processes the file and turns it into a GeographyQuiz.

   James MacPhee - B00768516 - Oct.13th/2018 */
import java.io.*;
import java.util.Scanner;
import java.util.Random;
public class GeographyQuiz{
   public static void main(String[] args) throws IOException{
      
      int num=0, score=0;
      List<Pair> pairs = new List<Pair>();
      File file = new File("CountriesCapitals.txt");
      Scanner inputFile = new Scanner(file);
      Scanner sc = new Scanner(System.in);
      Random rn = new Random(); //Random number to determine token number of input file
      
      //Populating List
      while (inputFile.hasNext()){
			Pair temp = new Pair(inputFile.nextLine(),inputFile.nextLine());
			pairs.add(temp);
		}
      System.out.print("welcome to the Country-Capital Quiz!\nPlay? ");
      String input = sc.next();
      
      //Start of quiz loop
      while(input.equals("yes")){
         int rand = rn.nextInt(201)+1;
         Pair tmp = pairs.first();
         for(int i=1;i<rand;i++){
            tmp = pairs.next();
         }
         String ans=null;
         if(rand%2==0){ //Determines whihc question to ask
            System.out.println("What is the capital of "+tmp.getCountry()+"?");
            ans = sc.next();
            if(ans.equals(tmp.getCapital())){
               System.out.println("Correct!");
               score++;
            }
            else System.out.print("Incorrect the correct answer is "+tmp.getCapital()+". ");
         }
         else{
            System.out.println("What country has "+tmp.getCapital()+" as its capital?");
            ans=sc.next();
            if(ans.equals(tmp.getCountry())){
               System.out.println("Correct!");
               score++;
            }
            else System.out.print("Incorrect the correct answer is "+tmp.getCountry()+". ");
         }
         System.out.print("Play? ");
         input = sc.next();
         num++;
      }
      int percent = 0;
      System.out.println("\nGame Over.\nGame Stats:");
      System.out.println("Questions played: "+num+"; Correct answers: "+score+"; Score: "+score/num+"%");
   }
}