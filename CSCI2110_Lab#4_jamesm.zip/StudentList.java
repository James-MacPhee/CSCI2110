/* CSCI2110 - Lab#4 - StudentList

   Defines a studentlist, that uses the Student class and the List class

   James MacPhee - B00768516 - Oct.13th/2018 */
public class StudentList{
   private List<Student> students;
   
   public StudentList(){
      students = new List<Student>();
   }
   //Adds a student record to the list
   public void addRecord(Student s){
      students.add(s);
   }
   //Delete a student record with the specified ID
   public void deleteRecord(int ID){
      Student stu = students.first();
      while(stu!=null){
         if(stu.getID()==ID){
            System.out.println(stu.getID()+" deleted.");
            students.remove(stu);
            return;
         }
         stu = students.next();
      }
      System.out.println("ID number not found");
   }
   //Displays all students in the list that are majoring in the inputted major
   public void displayMajors(String major){
      Student stu = students.first();
      while(stu!=null){
         if(stu.getMajor().equals(major)) System.out.println(stu);
         stu = students.next();
      }
   }
   //Displays all students in the list that belong to the inputted faculty
   public void displayFaculty(String faculty){
      Student stu = students.first();
      while(stu!=null){
         if(stu.getFaculty().equals(faculty)) System.out.println(stu);
         stu = students.next();
      }
   }
   //Displays all students in the list with the inputted last name
   public void displayName(String lName){
      Student stu = students.first();
      while(stu!=null){
         if(stu.getLname().equals(lName)) System.out.println(stu);
         stu = students.next();
      }
   }
   //Method to search for a student with the inputted ID number
   public Student searchID(int ID){
      Student stu = students.first();
      while(stu!=null){
         if(stu.getID()==ID) return stu;
         stu = students.next();
      }
      System.out.println(ID+" not found.");
      return null;
   }
   //Method to return the first student in the list
   public Student first(){
		return students.first();
	}
   //Method to return the next student in the list(in relation to last call to next() or first())
	public Student next(){
		return students.next();
	}
}