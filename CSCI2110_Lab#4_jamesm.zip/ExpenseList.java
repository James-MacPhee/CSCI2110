//ExpenseList class
//Defines an unordered list of Expense objects
//Uses the generic unordered list (List<T>) class and Expense class
public class ExpenseList{
	private List<Expense> expenses;
	
	public ExpenseList(){
		expenses = new List<Expense>();
	}
	public void add(Expense exp){
		expenses.add(exp);
	}
	public boolean isEmpty(){
		return expenses.isEmpty();
	}
	public boolean contains(Expense exp){
		return expenses.contains(exp);
	}
	public Expense first(){
		return expenses.first();
	}
	public Expense next(){
		return expenses.next();
	}
	public void enumerate(){
		expenses.enumerate();
	}
   //Finds and returns the costliest expense of the month
	public double maxExpense(){
		double max =0.0, amt;
		Expense exp = expenses.first();
		while (exp!=null){
			amt = exp.getAmount();
			if (amt>max)
				max = amt;
			exp = expenses.next();
		}
		return max;
	}
   //Finds and returns the cheapest expense of the month
	public double minExpense(){
		double min =Double.MAX_VALUE, amt;
		Expense exp = expenses.first();
		if (exp==null) return 0.0;
		else{
			while (exp!=null){
				amt = exp.getAmount();
				if (amt<min)
					min = amt;
				exp = expenses.next();
			}
		}
		return min;
	}
   //Calculates and returns the average cost per expense for the month
	public double avgExpense(){
		if(expenses.size()!=0) return totalExpense()/expenses.size();
      else return 0.0;
	}
	public double totalExpense(){
		double amt = 0.0;
		Expense exp = expenses.first();
	   while(exp!=null){
         amt += exp.getAmount();
			exp = expenses.next();
		}
      return amt;
   }
   //Finds and returns the amount spent on the user-inputted item
	public double amountSpentOn(String expItem){
		double amt = 0.0;
      Expense exp = expenses.first();
      while(exp!=null){
         if(exp.getItem().equals(expItem)){
            amt += exp.getAmount();
         }
         exp = expenses.next();
      }
      return amt;
	}
}