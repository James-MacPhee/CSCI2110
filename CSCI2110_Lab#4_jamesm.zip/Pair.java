/* CSCI2110 - Lab#4 - Pair

   Program defines a Pair as a pair of a country and its capital.

   James MacPhee - B00768516 - Oct.13th/2018 */
public class Pair{
   
   private String country;
   private String capital;
   
   public Pair(){
   }
   public Pair(String country,String capital){
      this.country=country; this.capital=capital;
   }
   
   //--- Get Methods ---
   public String getCountry(){
      return country;
   }
   public String getCapital(){
      return capital;
   }
}