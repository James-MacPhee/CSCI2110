/* CSCI2110 - Lab#4 - StudentListDemo

   Program reads a text file containing list of students.
   File contains studentID, name, email, major and faculty on each line.
   Program then processes the file and displays student data.

   James MacPhee - B00768516 - Oct.13th/2018 */
import java.util.Scanner;
import java.io.*;
public class StudentListDemo{
	public static void main(String[] args) throws IOException{
		Scanner keyboard = new Scanner(System.in);
		System.out.print("Enter the filename to read from: ");
		String filename = keyboard.nextLine();
		
		File file = new File(filename);
		Scanner inputFile = new Scanner(file);
		
		StudentList students = new StudentList();
		int ID;
      String fname,lname,email,major,faculty;
		Student stu=null;
		
		while (inputFile.hasNext()){
			ID= inputFile.nextInt();
			fname = inputFile.next();
         lname = inputFile.next();
			email = inputFile.next();
         major = inputFile.next();
         faculty = inputFile.next();
			stu = new Student(ID,fname,lname,email,major,faculty);
			students.addRecord(stu);
		}
		inputFile.close();		
		
		System.out.print("What would you like to do? (add, delete, display, search, quit): ");
      String input = keyboard.next();
      
      while(!input.equals("quit")){
         if(input.equals("add")){
            System.out.print("Enter the record: ");
            Student tmp = new Student(keyboard.nextInt(),keyboard.next(),keyboard.next(),keyboard.next(),keyboard.next(),keyboard.next());
            students.addRecord(tmp);
            System.out.println("Record added.");
         }
         else if(input.equals("delete")){
            System.out.print("Enter the ID number to be deleted: ");
            students.deleteRecord(keyboard.nextInt());
         }
         else if(input.equals("display")){
            System.out.print("Display what (major, faculty, student): ");
            String choice = keyboard.next();
            if(choice.equals("major")){
               System.out.print("Enter the major: ");
               students.displayMajors(keyboard.next());
            }
            else if(choice.equals("faculty")){
               System.out.print("Enter the faculty: ");
               students.displayFaculty(keyboard.next());
            }
            else if(choice.equals("student")){
               System.out.print("Enter the last name: ");
               students.displayName(keyboard.next());
            }
            else System.out.println("Improper input, please try again.");
         }
         else if(input.equals("search")){
            System.out.println("Enter the ID number: ");
            Student stud = students.searchID(keyboard.nextInt());
            if(stud!=null) System.out.println(stud);
         }
         else System.out.println("Improper input, please try again.");
         
         System.out.println("What would you like to do? (add, delete, display, search, quit):");
         input = keyboard.next();
      }
      System.out.println("Program ended.");
	}
}