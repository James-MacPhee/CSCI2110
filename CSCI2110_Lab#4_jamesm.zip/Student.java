/* CSCI2110 - Lab#4 - Student

   Defines a student object, that is to be used in the StudentList class

   James MacPhee - B00768516 - Oct.13th/2018 */
public class Student{
   
   public int studentID;
   public String fname,lname,email,major,faculty;
   
   public Student(){
   }
   public Student(int id,String fn,String ln,String email,String maj,String fac){
      studentID=id; fname=fn; lname=ln; email=email; major=maj; faculty=fac;
   }
   //toString method
   public String toString(){
      return studentID+" "+fname+" "+lname+" "+email+" "+major+" "+ faculty;
   }
   //--- Get methods ---
   public int getID(){
      return studentID;
   }
   public String getFname(){
      return fname;
   }
   public String getLname(){
      return lname;
   }
   public String getEmail(){
      return email;
   }
   public String getMajor(){
      return major;
   }
   public String getFaculty(){
      return faculty;
   }
}