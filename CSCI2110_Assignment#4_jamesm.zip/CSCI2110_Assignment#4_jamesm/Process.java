//CSCI2110 - Assignment #4 - Process class
//*****
//Defines a process to be placed into the heap
//*****
//James MacPhee - B00768516 - Nov.24th/2018
public class Process{	
   private int id;
   private int	timeReqd;
   private int priority;
   private int	timeArrival;
   
   //get, set and other	methods as required
   public Process(int id,int timeReqd,int priority,int timeArrival){
      this.id=id; this.timeReqd=timeReqd; this.priority=priority; this.timeArrival=timeArrival;
   }
   //compareTo method to compare prioritys
   public int compareTo(Process P){
      int temp1 = this.getPriority();
      int temp2 = P.getPriority();
      
      if(temp1>temp2) return 1;
      else return 0;
   }
   //Get methods
   public int getPriority(){
      return priority;
   }
   public int getId(){
      return id;
   }
   public int getTimeReqd(){
      return timeReqd;
   }
   public int getTimeArrival(){
      return timeArrival;
   }
   //toString method
   public String toString(){
      return "("+getId()+" "+getTimeReqd()+" "+getPriority()+" "+getTimeArrival()+")";
   }
}