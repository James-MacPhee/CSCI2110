//CSCI2110 - Assignment #4 - HeapDemo
//*****
//This program simulates how a CPU uses the heap data structure for process scheduling.
//*****
//James MacPhee - B00768516 - Nov.24th/2018
import java.util.Scanner;
import java.io.*;
public class HeapDemo{
   public static void main(String[] args) throws IOException{
      
      File file = new File("input");
		Scanner inputFile = new Scanner(file);
      
      int id, timeReqd, priority, timeArrival;
      Heap heap = new Heap();
      //Creating processes from input file data and adding them to heap
      while (inputFile.hasNext()){
         id = inputFile.nextInt();
         timeReqd = inputFile.nextInt();  
			priority = inputFile.nextInt();
         timeArrival = inputFile.nextInt();
         Process temp = new Process(id,timeReqd,priority,timeArrival);
         heap.add(temp);
		}
      int count=1;
      //Print-out of each timeunit continues until heap is empty
      while(!heap.isEmpty()){
         System.out.println("\nTime Unit: "+count);
         System.out.printf("Heap: ");
         heap.enumerate();
         Process temp = heap.deleteMax();
         if(!heap.isEmpty()) heap.enumerate();
         if(!heap.isEmpty()) heap.enumerate();
         System.out.printf("\nCPU: ");
         System.out.println("["+temp+"]");
         count++;
      }
   }
}