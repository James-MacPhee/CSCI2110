//I made a simple Node class to make my HashMap graph
import java.util.ArrayList;

public class Node{
   String label;
   ArrayList<Node> list;
   
   //Constructor
   public Node(String label){
      this.label=label;
      list = new ArrayList<Node>();
   }
   //Adds a node to its adjancency list
   public void add(Node n){
      list.add(n);
   }
   //Gets label
   public String getLabel(){
      return label;
   }
   //Gets adjancency list
   public ArrayList<Node> getList(){
      return list;
   }
}