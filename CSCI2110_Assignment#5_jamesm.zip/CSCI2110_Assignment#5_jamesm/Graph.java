//James MacPhee - Assignment #5 - Graph.java
//This program ..................................................
//B00768516 - Nov.30th/2018
import java.io.*;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.HashMap;

public class Graph{
   public static void main(String[] args) throws IOException{
      
      Scanner sc = new Scanner(System.in);
      System.out.print("Please enter input file name: ");
      File file = new File(sc.nextLine());
      Scanner input = new Scanner(file);
      
      HashMap<String, Node> graph = new HashMap<String, Node>();
      
      //Creating and filling adjacency matrix
      int num = Integer.parseInt(input.nextLine());
      int arr[][] = new int[num][num];
      String save = null;
      int count=0;
      while(input.hasNext()){
         String first = input.next();
         if(count==0) save = first;
         Node temp1 = new Node(first);
         String second = input.next();
         Node temp2 = new Node(second);
         temp1.add(temp2);
         temp2.add(temp1);
         if(!graph.containsValue(first)) graph.put(first,temp1);
         else graph.get(first).add(temp2);
         if(!graph.containsValue(second)) graph.put(second,temp2);
         else graph.get(second).add(temp1);
         int x = first.charAt(0)-65;
         int y = second.charAt(0)-65;
         arr[x][y] = 1;
         arr[y][x] = 1;
         count++;
      }
      //Displaying adjancency matrix
      System.out.println("Adjancency Matrix");
      for(int i=0;i<num;i++){
         for(int j=0;j<num;j++){
            System.out.print(arr[i][j]+"\t");
         }
         System.out.println("\n");
      }
      traverse(save, graph);
   }
   //Breadth First Search Traversal Algorithm
   public static void traverse(String save, HashMap<String, Node> graph){
      ArrayList<Node> queue = new ArrayList<Node>();
      ArrayList<Node> result = new ArrayList<Node>();
      queue.add(graph.get(save));
      System.out.println("Traversal:");
      while(!queue.isEmpty()){
         Node temp = queue.remove(0);
         result.add(temp);
         while(!temp.getList().isEmpty()){
            if(!result.contains(temp.getList().get(0)) && !queue.contains(temp.getList().get(0))) queue.add(temp.getList().get(0));
            temp.getList().remove(0);
         }
      }
      for(int i=0;i<result.size();i++){
         System.out.println(result.get(i).getLabel());
      }
   }
}