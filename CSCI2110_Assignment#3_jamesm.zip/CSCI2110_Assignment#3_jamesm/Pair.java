/* CSCI 2110 - Assignment #3 - Pair 

   This program defines a Pair object as a letter and its frequency

   James MacPhee - B00768516 - Nov.10th 2018 */
public class Pair{
   
   private char letter;
   private double prob;
   
   public Pair(char letter,double prob){
      this.letter=letter; this.prob=prob;
   }
   //--- Get and Set methods ---
   public char getLetter(){
      return letter;
   }
   public double getProb(){
      return prob;
   }
   public void setLetter(char letter){
      this.letter=letter;
   }
   public void setProb(double prob){
      this.prob=prob;
   }
   //toString method
   public String toString(){
      return "Letter: "+letter+"\tProb: "+prob;
   }
}