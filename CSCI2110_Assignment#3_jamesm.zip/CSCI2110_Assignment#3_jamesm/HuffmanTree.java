/* CSCI 2110 - Assignment #3 - HuffmanTree 

   This program creates a Huffman coding tree using the values given in 'Frequency.txt',
   then uses that to encode and decode 'Pokemon.txt'.
   **I used the GenericQueue class we created in lab#3 instead of an ArrayList because I thought it would be cool**

   James MacPhee - B00768516 - Nov.10th 2018 */
import java.util.ArrayList;
import java.util.StringTokenizer;
import java.util.Scanner;
import java.io.*;
public class HuffmanTree{
   
   //Main method
   public static void main(String[] args) throws IOException{
      
      ArrayList<Pair> pairs = new ArrayList<Pair>();
      File freq = new File("Frequency.txt");
      File pokemon = new File("Pokemon.txt");
      Scanner freqInput = new Scanner(freq); //Scanner for frequency file
      Scanner pokeInput = new Scanner(pokemon); //Scanner for pokemon file
      pokeInput.useDelimiter("");
      
      //While loop to create 'Pairs' from text file
      while(freqInput.hasNext()){
         Pair temp = new Pair(freqInput.next().charAt(0),freqInput.nextDouble());
         pairs.add(0,temp);
      }
      GenericQueue<BinaryTree<Pair>> S = new GenericQueue<BinaryTree<Pair>>();
      //Enqueuing all Pairs to the Queue
      while(!pairs.isEmpty()){
         BinaryTree<Pair> temp = new BinaryTree<Pair>();
         temp.setData(pairs.get(0));
         S.enqueue(temp);
         pairs.remove(0);
      }
      GenericQueue<BinaryTree<Pair>> T = new GenericQueue<BinaryTree<Pair>>();
      BinaryTree<Pair> huffTree = buildTree(S,T); //Building Huffman tree
      String[] encoded = findEncoding(huffTree); //Find encoding for each letter
      String[] arr = {"A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"}; //Alphabet array to match
      
      FileWriter writer = new FileWriter("Encoded.txt");
      PrintWriter printWriter = new PrintWriter(writer);
      
      while(pokeInput.hasNext()){
         String temp = pokeInput.next();
         if(temp.equals(" ")) printWriter.print(" ");
         else if(temp.equals("\n")) printWriter.print("\n");
         else{
            for(int i=0;i<26;i++){
               if(temp.equals(arr[i])) printWriter.print(encoded[i]);
            }
         }
      }
      printWriter.close();
      
      //Next chunk decodes "Encoded.txt" and prints results to "Decoded.txt"
      FileWriter writer2 = new FileWriter("Decoded.txt");
      PrintWriter printWriter2 = new PrintWriter(writer2);
      File encodeFile = new File("Encoded.txt");
      
      Scanner encodeInput = new Scanner(encodeFile); //Scanner for encode file
      encodeInput.useDelimiter("");
      String tmp = "";
      //This chunk checks if first digit matches any elements of array. If yes then prints corresponding letter, if no then append next digit and repeat.
      while(encodeInput.hasNext()){
         tmp += encodeInput.next();
         if(tmp.equals(" ")){
            printWriter2.print(" ");
            tmp = "";
         }
         if(tmp.equals("\n")){
            printWriter2.print("\n");
            tmp = "";
         }
         for(int i=0;i<26;i++){
            if(encoded[i].equals(tmp)){
               printWriter2.print(arr[i]);
               tmp = "";
            }
         }
      }
      printWriter2.close();
   }
  
   //Method to create the Huffman tree
   public static BinaryTree<Pair> buildTree(GenericQueue<BinaryTree<Pair>>S,GenericQueue<BinaryTree<Pair>>T){
      BinaryTree<Pair> temp1 = new BinaryTree<Pair>();
      BinaryTree<Pair> temp2 = new BinaryTree<Pair>();
      //I wrote this eaxctly as it is written in the lab notes
      //****
      //If S is not empty
      while(!S.isEmpty()){
         //If T is empty two smallest are in front of S
         if(T.isEmpty()){
            temp1 = S.dequeue();
            temp2 = S.dequeue();
         }
         //If T is not empty
         else{
            if(S.first().getData().getProb()<T.first().getData().getProb()){
               temp1 = S.dequeue();
               if(S.first()==null) temp2 = T.dequeue();
               else if(S.first().getData().getProb()<T.first().getData().getProb()) temp2 = S.dequeue();
               else temp2 = T.dequeue();
            }
            else{
               temp1 = T.dequeue();
               if(S.first()==null) temp2 = T.dequeue();
               else if(T.first()==null) temp2 = S.dequeue();
               else if(S.first().getData().getProb()<T.first().getData().getProb()) temp2 = S.dequeue();
               else temp2 = T.dequeue();
            }
         }
         BinaryTree<Pair> P = new BinaryTree<Pair>();
         Pair tempPair = new Pair('&',temp1.getData().getProb()+temp2.getData().getProb());
         P.setData(tempPair);
         P.attachLeft(temp1);
         P.attachRight(temp2);
         T.enqueue(P);
      }
      //While T has more than 1 element add them together and create parent of combined value and repeat until only 1 element
      while(T.size()>1){
         temp1 = T.dequeue();
         temp2 = T.dequeue();
         BinaryTree<Pair> P = new BinaryTree<Pair>();
         Pair tempPair = new Pair('&',temp1.getData().getProb()+temp2.getData().getProb());
         P.setData(tempPair);
         P.attachLeft(temp1);
         P.attachRight(temp2);
         T.enqueue(P);
      }
      return T.first();
   }
   
   //Following two methods are unchanged from how they were in the lab notes
   public static void findEncoding(BinaryTree<Pair> t, String[] a, String prefix){
      if (t.getLeft()==null&& t.getRight()==null){
         a[((byte)(t.getData().getLetter()))-65]= prefix;
      }
      else{
         findEncoding(t.getLeft(), a, prefix+"0");
         findEncoding(t.getRight(), a, prefix+"1");
      }
   }
   public static String[] findEncoding(BinaryTree<Pair> t){
      String[] result = new String[26];
      findEncoding(t, result, "");
      return result;
   }
}